# -*- coding: utf-8 -*-
#%%
import warnings
warnings.filterwarnings('ignore')
from datetime import datetime,timedelta
import pandas as pd
import sqlalchemy
import numpy as np
from my_functions import my_functions
from slope_demo_report import build_report, build_backtest_report
my_func = my_functions()
pd.options.mode.chained_assignment = None

def_currency='USD'
ini_amt = 1000000
stk_num = 5
single_amt = ini_amt/stk_num

# strategy
stg_ID='01'
para=[]
# para_period = [90,150,10]
# para_crt_chg = [0.004,0.007,0.0002]
para_period = [90,150,30]
para_crt_chg = [0.005,0.006,0.0002]
stop_loss = -0.25
# 
stg_Name='slope'
#stg_Part_ID='qt001'
index='SPX Index'

stk_type = 0 #0:stock,1:ETF
group_='1'
fund_unit =index


#backtest
backtest = 1
optimize = 0
load_para = 0
output_SQL = 0



# ini_amount、slippage 因暫時不計算其他費用，因此提高滑價方式替代、commision、tax_s(印花稅，賣出收，政府)、dvd_tax、round_lot
performance_set=[ini_amt,0.001,0.001,0.001,0.3,1,single_amt]
stg_type=1 # 0:fundamental;1:technical
avg_ic=0
sth_fn_name = 'strategy_'+stg_Name+'_indicator'
m = globals()['my_functions']()
stg_func = getattr(m, sth_fn_name)


# date
date_format = '%Y%m%d'
if (backtest ==1):
    # start_date = '20070101'
    # start_trade_date = '20080101'
    start_date = '20190101'
    start_trade_date = '20200101'
    if (optimize ==1):
        end_date_ori = datetime.strptime('20230630', date_format)
    else:
        end_date_ori = datetime.today().date()
else:
    end_date_ori = datetime.today().date()
    start_date = datetime.strftime((end_date_ori + timedelta(days=-1000)), date_format)
    # start_trade_date = datetime.strftime((end_date + timedelta(days=-1)), date_format)
    start_trade_date = datetime.strftime((end_date_ori), date_format)
start_trade_date_d = datetime.strptime(start_trade_date,date_format)
end_date = datetime.strftime(end_date_ori, date_format)

#linkSQL
engine = sqlalchemy.create_engine(r'mssql+pyodbc://cowork:cowork1234@PC09801\SQLEXPRESS/FA?driver=ODBC+Driver+17+for+SQL+Server')
conn = engine.connect()

params = {'index_': index, 'StartDt': start_date, 'EndDt': end_date}

# input Data fin for signal
trans = conn.begin()
try:
    cursor_fin = my_func.exec_procedure(conn, 'pivot_StkFinQ_1', params)
    cols_fin = list(cursor_fin.keys())
    df_fin = pd.DataFrame(cursor_fin.fetchall(), columns=cols_fin)
    trans.commit()
except:
    trans.rollback()
    raise
# # 只選想回測的項目
cols_fin_new=cols_fin[0:2] + ['TOTAL_EQUITY']
df_fin = df_fin[cols_fin_new]
## 調整格式與名稱
df_fin.rename(columns={'revision_date': 'date'},inplace=True)
df_fin['date'] = pd.to_datetime(df_fin['date'], format= date_format)
df_fin.dropna(inplace=True)   # pivot後會有空值
df_fin.drop_duplicates(subset =['date','stk_bbg'],keep='last',inplace=True)  # 如果同一天公布，取最新數字

# input Data index for trade
trans = conn.begin()
try:
    cursor_idx = my_func.exec_procedure(conn, 'com_Idx_1', params)
    cols_idx = list(cursor_idx.keys())
    df_idx = pd.DataFrame(cursor_idx.fetchall(), columns=cols_idx)
    trans.commit()
except:
    trans.rollback()
    raise
    
# input Adj Data
trans = conn.begin()
try:
    cursor_adjfactor= my_func.exec_procedure(conn, 'com_Adj_Factor_1', params)
    cols_adjfactor = list(cursor_adjfactor.keys())
    df_adjfactor = pd.DataFrame(cursor_adjfactor.fetchall(), columns=cols_adjfactor)
    df_adjfactor = df_adjfactor.sort_values(by='stk_bbg')
    trans.commit()
except:
    trans.rollback()
    raise
df_adjfactor['Adj_Factor_rev'] = df_adjfactor['Adj_Factor']
df_adjfactor.loc[df_adjfactor['Adj_Factor_Operator_Type'] == 2, 'Adj_Factor_rev'] = 1/df_adjfactor['Adj_Factor']

# input Data index for signal
trans = conn.begin()
sql=sqlalchemy.text("""select date_, PX_Return, PX_OPEN, PX_LAST from TecD where stk_bbg = '""" + index + """' and date_ between '""" + start_date +"""' and '""" +  end_date + """' order by date_ asc;""")
try:
    cursor_index  = conn.execute(sql)
    cols_index  = cursor_index.keys()
    df_index = pd.DataFrame(cursor_index.fetchall())
    df_index.columns=cols_index
    trans.commit()
except:
    trans.rollback()
    raise
    
# input Data tech for signal
trans = conn.begin()
try:
    cursor_tec= my_func.exec_procedure(conn, 'com_TecD_1', params)
    cols_tec = list(cursor_tec.keys())
    df_tec = pd.DataFrame(cursor_tec.fetchall(), columns=cols_tec)
    df_tec = df_tec.sort_values(by='date_')
    trans.commit()
except:
    trans.rollback()
    raise
                                      
# # 以最後一天的資料最為最新資料計算最新訊號                                        
last_date = df_tec.iloc[-1]['date_']
df_add_tec = df_tec.loc[df_tec['date_'] == last_date, ['date_', 'stk_bbg', 'PX_OPEN','PX_HIGH', 'PX_LOW', 'PX_LAST']] 
df_add_tec['date_'] = datetime.strftime(datetime.today().date(), date_format)
df_add_tec['PX_Return']=0
df_tec = pd.concat([df_tec, df_add_tec], ignore_index=True)
df_tec = df_tec.merge(df_adjfactor, left_on=['stk_bbg', 'date_'], right_on=['stk_bbg', 'Adj_date'], how='outer', indicator=True)
df_tec['Adj_Factor_rev'].fillna(1,inplace=True)
# 確認是否有adj_factor非交易日
# 紀錄確認是否有adj_factor非交易日
df_tec = df_tec[['stk_bbg','date_','PX_OPEN','PX_HIGH','PX_LOW','PX_LAST','PX_VOLUME','EQY_SH_OUT','PX_Return','Adj_Factor','Adj_Factor_rev']].sort_values(['stk_bbg','date_'])
df_tec['Adj_Factor_Cul'] = df_tec.groupby(['stk_bbg'])['Adj_Factor_rev'].cumprod()
df_tec = df_tec.drop_duplicates(subset=['stk_bbg', 'date_'],keep='last')
df_tec = df_tec.dropna(subset=['PX_LAST'])
# 刪除非交易日
df_tec.sort_values(['date_','stk_bbg'],inplace=True)
df_temp = df_tec.groupby(['stk_bbg']).apply(lambda x :x['PX_Return']-((x['PX_LAST']*x['Adj_Factor_Cul'])/(x['PX_LAST'].shift(1)*x['Adj_Factor_Cul'].shift(1))-1))
# 紀錄股利
df_tec['DVD'] = df_temp.reset_index(level=0,drop=True)
df_tec['DVD'].fillna(0,inplace=True)
df_tec['DVD']=df_tec['DVD'].apply(lambda x: 0 if abs(x)<0.0001 else x)
# 紀錄是否最後一個交易日，若最後一個交易日有持股則出清持股
df_tec['t'] = 1
df_tec.loc[df_tec.groupby('stk_bbg').tail(1).index,'t']=0
df_tec.loc[df_tec['date_']==df_tec.date_.tail(1).values[0],'t']=1     #最後一天設為交易日
# MCap
df_tec['MCap'] = df_tec['EQY_SH_OUT'] * df_tec['PX_LAST']
# ## 調整格式與名稱
df_fin.rename(columns={'revision_date': 'date'},inplace=True)
df_fin['date'] = pd.to_datetime(df_fin['date'], format= date_format)
df_idx.rename(columns={'date_':'date'},inplace=True)
df_idx['date'] = pd.to_datetime(df_idx['date'], format= date_format)
if df_idx.iloc[-1,0]!=datetime.combine(end_date_ori, datetime.min.time()):
    df_add_idx = df_idx.loc[df_idx['date']==df_idx.iloc[-1,0],]
    df_add_idx['date'] = datetime.combine(end_date_ori, datetime.min.time())
    df_idx = pd.concat([df_idx, df_add_idx], ignore_index=True)
df_tec.rename(columns={'date_':'date'},inplace=True)
df_tec['date'] = pd.to_datetime(df_tec['date'], format= date_format)
df_index.rename(columns={'date_':'date'},inplace=True)
df_index['date'] = pd.to_datetime(df_index['date'], format= date_format)
if df_index.iloc[-1,0]!=datetime.combine(end_date_ori, datetime.min.time()):
    new_row = pd.DataFrame([{
        'date': datetime.combine(end_date_ori, datetime.min.time()),
        'PX_Return': 0
    }])
    df_index = pd.concat([df_index, new_row], ignore_index=True)
# GICs NA 補0
df_idx['GICS_SECTOR'].fillna('99',inplace=True)
df_idx['GICS_SECTOR'] = df_idx['GICS_SECTOR'].astype(int).astype(str)
df_idx['weight_']=df_idx['weight_']/100

## 日期
# 日曆日
cldr_dates = pd.DataFrame(df_idx.date.unique())
cldr_dates.columns=['date']
cldr_dates.drop_duplicates(['date'],inplace=True)
cldr_dates.set_index('date',inplace=True, drop=False)
idx_ret=cldr_dates.reset_index(drop=True).merge(df_index[['date','PX_Return']],on=['date'],how='left').set_index('date')
idx_ret['stk_bbg']=index
##交易日
trade_dates = pd.DataFrame(df_index.date.unique())
new_date = pd.DataFrame([datetime.combine(end_date_ori, datetime.min.time())])
trade_dates = pd.concat([trade_dates, new_date], ignore_index=True)
trade_dates.columns=['date']
trade_dates.drop_duplicates(['date'],inplace=True)
# 找出最近交易日
trade_dates.set_index('date',inplace=True, drop=False)
trade_dates_start = trade_dates.loc[trade_dates['date']>=start_trade_date_d]

date_map = cldr_dates.merge(trade_dates,left_index=True,right_index=True, how = 'left',suffixes=['_cldr','_trade'])
date_map['date_trade'].fillna(method='ffill',inplace =True)
date_map['date_trade_last'] = date_map['date_trade'].shift(1)
date_map.loc[date_map['date_trade']==date_map['date_trade_last'],'date_trade_last']=np.nan
date_map['date_trade_last'].ffill(inplace=True)
# # 調倉日期
# rebal_dates = pd.DataFrame(pd.date_range(start_trade_date,end_date,freq=rebal_freq), columns=['date'])
# rebal_dates = date_map[date_map['date_cldr'].isin(rebal_dates.date)]
# rebal_dates.reset_index(drop=True,inplace=True)

# combine index、tec、fin data
df_factor = pd.merge(df_idx,df_tec, on=['date','stk_bbg'],how='outer')
df_factor['DVD'].fillna(0,inplace=True)
df_factor['Adj_Factor_rev'].fillna(1,inplace=True)
# 如果當日停牌，，則t=2
df_factor['t'].fillna(2,inplace=True)
df_factor.sort_values(['date','stk_bbg'],inplace=True)
df_quant = pd.merge(df_factor,df_fin, on=['date','stk_bbg'],how='left')

# 補前值，先補fin
cols_fill_prev = cols_fin_new[2::]
df_quant[cols_fill_prev] = df_quant.groupby(['stk_bbg'])[cols_fill_prev].fillna(method='ffill')
# # 沒有收盤價的資料去除，除了最後一天
df_quant.loc[df_quant['date']==df_quant.iloc[-1,0],['PX_LAST','t']]=[0,1]
df_quant.dropna(subset=['PX_LAST'],inplace=True)
df_quant.loc[df_quant['date']==df_quant.iloc[-1,0],['PX_LAST']]=np.nan
df_quant['PX_LAST'] = df_quant.groupby(['stk_bbg'])['PX_LAST'].fillna(method='ffill')

# 若個股當日無交易，報酬率補0
df_quant['PX_Return'] = df_quant['PX_Return'].fillna(0)


# # # # winsorize
# # strategy_rank_data['PX_Return']=strategy_rank_data.groupby(['date'])['PX_Return'].apply(lambda x: my_func.winsorize(x, cutoff = {'std':[3,3]}, replace_with_cutoff =True))
# px_return = my_func.winsorize_arrays(strategy_rank_data,df_index['date','PX_Return'],trade_dates_start,100)
# strategy_rank_data.drop(labels=['PX_Return'],axis=1,inplace=True)
# strategy_rank_data = strategy_rank_data.merge(px_return, on=['date','stk_bbg'],how='left')


# 調整後收盤價
df_signal = df_quant[['date','stk_bbg','PX_OPEN','PX_HIGH','PX_LOW','PX_LAST','PX_Return','PX_VOLUME','Adj_Factor_Cul','weight_','t','TOTAL_EQUITY']]
df_signal = df_signal.groupby(['stk_bbg'],as_index=False).apply(lambda x: my_func.calculate_adjusted_prices(x,'PX_LAST','PX_Return'))

# # 限制條件
df_signal.loc[df_signal['TOTAL_EQUITY']<=0,'weight_']=np.nan

#%%
portfolio_1=pd.DataFrame(columns=['date','stk_bbg','signal','indicator'])
if optimize == 1:
    period_lengh = ((para_period[1]-para_period[0])//para_period[2])+1
    crt_chg_lengh = ((para_crt_chg[1]-para_crt_chg[0])//para_crt_chg[2])+1
    df_opt = pd.DataFrame()
    count_opt = 0
    for i in range(para_period[0], para_period[1] + para_period[2], para_period[2]):
        para=[stk_num,stop_loss,0,i]
        performance_set=[ini_amt,0.001,0.001,0.001,0.3,1,ini_amt/para[0]] # ini_amount、slippage、commision、tax_s(印花稅，賣出收，政府)、dvd_tax、round_lot
        # 在交易策略要確保沒有用到未來資料
        df_signal_all = stg_func(df_signal,df_index[['date','PX_Return']],trade_dates_start,para[3])
        signal_data = pd.merge(df_factor,df_signal_all,how='left',on=['date','stk_bbg'])
        for j in np.arange(para_crt_chg[0], para_crt_chg[1] + para_crt_chg[2], para_crt_chg[2]):
            para=[stk_num,stop_loss,j,i]
            portfolio_1=pd.DataFrame(columns=['date','stk_bbg','signal','indicator'])
            performance_year=my_func.performance_opt(signal_data,trade_dates_start,date_map,df_index,portfolio_1,performance_set,para)
            df_opt.loc[count_opt,'para_period'] = i
            df_opt.loc[count_opt,'para_crt_chg'] = j
            df_opt.loc[count_opt,'ret'] = performance_year['p_ret_cul'].tail(1).squeeze()
            df_opt.loc[count_opt,'alpha_year'] = len(performance_year.loc[performance_year['alpha']>0])
            count_opt = count_opt + 1

    # ====== 互動式報表 (Demo) ======
    # 1) 找出最佳參數組合 (依累積報酬，平手再比 Alpha 勝出年數)
    # best_row = df_opt.sort_values(['ret','alpha_year'], ascending=[False, False]).iloc[0]
    best_row = df_opt.sort_values(['alpha_year','ret'], ascending=[False, False]).iloc[0]
    best_period = int(best_row['para_period'])
    best_crt_chg = float(best_row['para_crt_chg'])
    print(f"[Demo] 最佳參數: Period={best_period}, Crt_Chg={best_crt_chg:.4f}, "
          f"Ret={best_row['ret']:.4f}, AlphaYrs={int(best_row['alpha_year'])}")

    # 2) 用最佳參數重跑一次完整回測 (取得每日績效、持股等明細)
    para = [stk_num, stop_loss, best_crt_chg, best_period]
    performance_set = [ini_amt, 0.001, 0.001, 0.001, 0.3, 1, ini_amt/para[0]]
    df_signal_all = stg_func(df_signal, df_index[['date','PX_Return']], trade_dates_start, para[3])
    signal_data = pd.merge(df_factor, df_signal_all, how='left', on=['date','stk_bbg'])
    portfolio_1 = pd.DataFrame(columns=['date','stk_bbg','signal','indicator'])
    performance_tlt, performance_year, performance, hold_portfolio, trade, holdings = \
        my_func.performance(signal_data, trade_dates_start, date_map,
                            df_index, portfolio_1, performance_set, para)

    # 3) 產生互動式 HTML 報表並自動開啟
    report_path = build_report(
        df_opt=df_opt,
        performance=performance,
        performance_year=performance_year,
        performance_tlt=performance_tlt,
        hold_portfolio=hold_portfolio,
        trade=trade,
        meta=dict(
            index=index,
            stk_num=stk_num,
            ini_amt=ini_amt,
            stop_loss=stop_loss,
            best_period=best_period,
            best_crt_chg=best_crt_chg,
            start_date=start_trade_date,
            end_date=end_date,
        ),
        output_path='slope_demo_report.html',
        auto_open=True,
    )
    print(f"[Demo] 互動式報表已輸出：{report_path}")
    # ====== 互動式報表 (Demo) END ======

elif load_para == 1:
    para=[]
    sql = sqlalchemy.text("""
        SELECT Para1, Para2, Para3 FROM qt_parameter
        WHERE date_ = (
            SELECT TOP 1 date_ FROM qt_parameter
            WHERE stg_id = :stg_id AND fund_unit = :fund_unit
            GROUP BY date_ ORDER BY date_ DESC
        )
        AND stg_id = :stg_id AND fund_unit = :fund_unit;
    """)
    params = {"stg_id": stg_ID, "fund_unit": fund_unit}
    try:
        # 2. 使用 pd.read_sql 簡潔地執行查詢
        paras_sql = pd.read_sql(sql, conn, params=params)
        # 3. 檢查查詢結果是否為空，防止 IndexError
        if paras_sql.empty:
            # 如果沒找到資料，引發一個明確的錯誤，方便除錯
            raise ValueError(f"在資料庫中找不到對應的參數 (stg_ID: {stg_ID}, fund_unit: {fund_unit})")
        # 4. 如果有資料，才進行後續的提取操作
        first_row = paras_sql.iloc[0]
        para = [first_row['Para1'],stop_loss,first_row['Para3'],int(first_row['Para2'])]
    except Exception as e:
        # 捕獲所有可能的錯誤 (資料庫錯誤或我們引發的 ValueError)
        print(f"讀取策略參數時發生錯誤: {e}")
        raise
     
    performance_set=[ini_amt,0.001,0.001,0.001,0.3,1,ini_amt/para[0]] # ini_amount、slippage、commision、tax_s(印花稅，賣出收，政府)、dvd_tax、round_lot    
    
    # 在交易策略要確保沒有用到未來資料
    df_signal_all = stg_func(df_signal,df_index[['date','PX_Return']],trade_dates_start,para[3])
    signal_data = pd.merge(df_factor,df_signal_all,how='left',on=['date','stk_bbg'])

    
    
    if backtest==1:
        performance_tlt,performance_year,performance,hold_portfolio,trade,holdings=my_func.performance(signal_data,trade_dates_start,date_map,df_index,portfolio_1,performance_set,para)
        # ====== 單次回測互動式報表 ======
        report_path = build_backtest_report(
            performance=performance,
            performance_year=performance_year,
            performance_tlt=performance_tlt,
            hold_portfolio=hold_portfolio,
            trade=trade,
            holdings=holdings,
            meta=dict(
                index=index, stk_num=para[0], ini_amt=ini_amt,
                stop_loss=stop_loss,
                period=int(para[3]), crt_chg=float(para[2]),
                start_date=start_trade_date, end_date=end_date,
            ),
            output_path='slope_backtest_report.html',
            auto_open=True,
        )
        print(f"[Demo] 單次回測報表已輸出：{report_path}")
        # ====== 單次回測互動式報表 END ======
    else:
        # input Data now holdings
        sql = f"""
            SELECT stk_bbg FROM qt_daily_signal_bystock
            WHERE date_ = (
                SELECT TOP 1 date_ FROM qt_daily_signal_bystock
                WHERE stg_id = ? AND group_ = ?
                GROUP BY date_
                ORDER BY date_ DESC
            ) AND stg_id = ? AND group_ = ?;
            """
        try:
            now_holdings = pd.read_sql(sql, conn, params=(stg_ID, group_, stg_ID, group_))
            # 檢查查詢結果是否為空
            if not now_holdings.empty:
                portfolio_1['stk_bbg'] = now_holdings['stk_bbg']
            # 可選：如果查詢結果為空，您可能希望清空持股
            else:
                portfolio_1['stk_bbg'] = None
        except Exception as e:
            print(f"讀取最新持股訊號時發生錯誤: {e}")
            raise
            
        performance_tlt,performance_year,performance,hold_portfolio,trade,holdings=my_func.performance(signal_data,trade_dates_start,date_map,df_index,portfolio_1,performance_set,para)
        
        if output_SQL == 1:
        
            # --- 步驟 1: 準備資料並定義資料庫欄位類型 ---
            hold_portfolio_sql = my_func.prepare_df_for_sql(hold_portfolio, stg_ID, group_,'indicator')

            sql_column_types = {
                'date_': sqlalchemy.types.VARCHAR(length=10),
                'stk_bbg': sqlalchemy.types.VARCHAR(length=50),
                'stg_id': sqlalchemy.types.VARCHAR(length=50),
                'signal': sqlalchemy.types.Integer(),
                'ranking': sqlalchemy.types.Float(),
                'group_': sqlalchemy.types.Integer(),
            }

            # --- 步驟 2: 將當日持股寫入 temp_table，用於後續的 DELETE 操作 ---
            hold_portfolio_sql.to_sql(
                'temp_table',
                engine,
                if_exists='replace',
                index=False,
                dtype=sql_column_types,
                method=None
            )

            # --- 步驟 3: 更新主訊號表 ---
            try:
                with engine.begin() as conn:
                    # 步驟 A: 根據 temp_table 的內容，刪除主表中的舊資料
                    delete_sql = sqlalchemy.text("""
                    DELETE FROM A FROM qt_daily_signal_bystock AS A
                    WHERE EXISTS (
                        SELECT 1 FROM temp_table AS B
                        WHERE A.date_ = B.date_ AND A.stg_id = B.stg_id AND A.group_ = B.group_
                    );
                    """)
                    conn.execute(delete_sql)

                    # 步驟 B: 將新的持股資料附加到主表中
                    hold_portfolio_sql.to_sql(
                        'qt_daily_signal_bystock',
                        con=conn,
                        if_exists='append',
                        index=False,
                        dtype=sql_column_types,
                        method=None
                    )
            except Exception as e:
                print(f"更新 qt_daily_signal_bystock 時發生錯誤: {e}")
                raise
            
            # --- 步驟 4: 產生當日交易清單 ---
            buy_list = hold_portfolio.loc[~hold_portfolio['stk_bbg'].isin(portfolio_1['stk_bbg']), 'stk_bbg']
            buy_portfolio = signal_data[(signal_data['date'] == end_date) & (signal_data['stk_bbg'].isin(buy_list))]

            sell_list = portfolio_1.loc[~portfolio_1['stk_bbg'].isin(hold_portfolio['stk_bbg']), 'stk_bbg']
            sell_portfolio = signal_data[(signal_data['date'] == end_date) & (signal_data['stk_bbg'].isin(sell_list))].copy()
            sell_portfolio['signal'] = -1

            trade_portfolio = pd.concat([buy_portfolio, sell_portfolio], ignore_index=True)

            # --- 步驟 5: 使用同一個輔助函式準備交易清單，並覆蓋 temp_table ---
            trade_portfolio_sql = my_func.prepare_df_for_sql(trade_portfolio, stg_ID, group_,'indicator')

            trade_portfolio_sql.to_sql(
                'temp_table',
                engine,
                if_exists='replace',
                index=False,
                dtype=sql_column_types,
                method=None
            )

            # --- 更新交易資料庫 ---
            try:
                with engine.begin() as conn:
                    # 步驟 A: 根據 temp_table 的內容，刪除主表中的舊資料
                    delete_sql = sqlalchemy.text("""
                    DELETE FROM A FROM qt_daily_signal AS A
                    WHERE EXISTS (
                        SELECT 1 FROM temp_table AS B
                        WHERE A.date_ = B.date_ AND A.stg_id = B.stg_id AND A.group_ = B.group_
                    );
                    """)
                    conn.execute(delete_sql)

                    # 步驟 B: 將新的交易資料附加到主表中
                    trade_portfolio_sql.to_sql(
                        'qt_daily_signal',
                        con=conn,
                        if_exists='append',
                        index=False,
                        dtype=sql_column_types,
                        method=None
                    )
            except Exception as e:
                print(f"更新 qt_daily_signal_bystock 時發生錯誤: {e}")
                raise

            # --- 更新 signal_all 至資料庫 ---
            # 1. 準備來源 DataFrame
            # 篩選出最後一個交易日的所有非零訊號
            signal_all_df = signal_data[
                (signal_data['date'] == date_map.iloc[-1, 0]) & (signal_data['signal'] != 0)
            ]
            signal_all_for_sql = my_func.prepare_df_for_sql(signal_all_df, stg_ID, group_,'indicator')
            # 2. 將準備好的資料覆蓋寫入 temp_table，用於後續的刪除操作
            signal_all_for_sql.to_sql(
                'temp_table',
                engine,
                if_exists='replace',
                index=False,
                dtype=sql_column_types,
                method=None
            )
            
            # 3. 在一個原子交易中，更新 qt_daily_signal_all 主資料表
            try:
                with engine.begin() as conn:
                    # 步驟 A: 根據 temp_table 的內容，刪除主表中的舊資料
                    delete_sql = sqlalchemy.text("""
                    DELETE FROM A
                    FROM qt_daily_signal_all AS A
                    WHERE EXISTS (
                        SELECT 1 FROM temp_table AS B
                        WHERE A.date_ = B.date_ AND A.stg_id = B.stg_id AND A.group_ = B.group_
                    );
                    """)
                    conn.execute(delete_sql)

                    # 步驟 B: 將新的訊號資料附加到主表中
                    signal_all_for_sql.to_sql(
                        'qt_daily_signal_all',
                        con=conn,
                        if_exists='append',
                        index=False,
                        dtype=sql_column_types,
                        method=None
                    )
            except Exception as e:
                print(f"更新 qt_daily_signal_all 時發生錯誤: {e}")
                raise 

else:
    para=[5, -0.25, 0.0058, 120]
    performance_set=[ini_amt,0.001,0.001,0.001,0.3,1,ini_amt/para[0]] # ini_amount、slippage、commision、tax_s(印花稅，賣出收，政府)、dvd_tax、round_lot
    # 在交易策略要確保沒有用到未來資料
    df_signal_all = stg_func(df_signal,df_index[['date','PX_Return']],trade_dates_start,para[3])
    signal_data = pd.merge(df_factor,df_signal_all,how='left',on=['date','stk_bbg'])
    performance_tlt,performance_year,performance,hold_portfolio,trade,holdings=my_func.performance(signal_data,trade_dates_start,date_map,df_index,portfolio_1,performance_set,para)
    # ====== 單次回測互動式報表 ======
    report_path = build_backtest_report(
        performance=performance,
        performance_year=performance_year,
        performance_tlt=performance_tlt,
        hold_portfolio=hold_portfolio,
        trade=trade,
        holdings=holdings,
        meta=dict(
            index=index, stk_num=para[0], ini_amt=ini_amt,
            stop_loss=stop_loss,
            period=int(para[3]), crt_chg=float(para[2]),
            start_date=start_trade_date, end_date=end_date,
        ),
        output_path='slope_backtest_report.html',
        auto_open=True,
    )
    print(f"[Demo] 單次回測報表已輸出：{report_path}")
    # ====== 單次回測互動式報表 END ======

# trade_log, trade_profile = my_func.cal_trade_profile(trade, hold_portfolio, plot_distribution=False, init_amt=1e8)

conn.close()

