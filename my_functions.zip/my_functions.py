# -*- coding: utf-8 -*-
"""
Created on Wed Jul 17 09:48:03 2019

@author: blptw
"""

import pandas as pd
import numpy as np
import _pickle as pickle
from dateutil import relativedelta
from itertools import chain, tee
from tkinter import messagebox
from collections import OrderedDict
import time
from scipy.stats import zscore, skew, kurtosis, mstats
from sqlalchemy import text
import matplotlib.pyplot as plt

class my_functions:
    def __init__(self):
        pass
    def prepare_df_for_sql(self,df, stg_id, group_id, p_factor_col):
        """一個共用函式，用來準備寫入資料庫的 DataFrame。"""
        output_df = df.copy()
        # 檢查 'date' 和 p_factor_col 是否存在，避免 rename 錯誤
        rename_dict = {}
        if 'date' in output_df.columns:
            rename_dict['date'] = 'date_'
        if p_factor_col in output_df.columns:
            rename_dict[p_factor_col] = 'ranking'
        if rename_dict:
            output_df = output_df.rename(columns=rename_dict)

        output_df = output_df.assign(stg_id=stg_id, group_=group_id)

        if 'date_' in output_df.columns:
            output_df['date_'] = output_df['date_'].dt.strftime('%Y%m%d')

        final_columns = ['date_', 'stk_bbg', 'stg_id', 'signal', 'ranking', 'group_']
        # 篩選出 DataFrame 中實際存在的欄位，使函式更穩健
        existing_cols = [col for col in final_columns if col in output_df.columns]
        return output_df[existing_cols]
    
    def mask_first(self,x):
        result = np.ones_like(x)
        result[0] = 0
        return result
    
    def numpy_flat(self,a):
        return list(np.array(a).flat)
    
    def exec_procedure(self,session, proc_name, params):
        # 將參數值加上引號並格式化為 SQL 字串
        sql_params = ", ".join([f"@{name}='{value}'" for name, value in params.items()])

        # 建立 SQL 字串，直接插入 proc_name 與參數值
        sql_string = f"""
            DECLARE @return_value int;
            EXEC @return_value = [dbo].[{proc_name}] {sql_params};
            SELECT 'Return Value' = @return_value;
        """
        # 執行 SQL
        return session.execute(text(sql_string))
    
    def load_cached_data(self):
        try: #try to read saved data. if saved file is not exist, create a new DataFrame
            f = open('data_cached.pckl', 'rb')
            cached_dict = pickle.load(f)
            f.close()
            return cached_dict
        except:
            return dict()
        
    def save_cached_data(self,cached_dict):
    #     print(cached_dict)
        f=open('data_cached.pckl','wb')
        pickle.dump(cached_dict, f)
        f.close()
     
    def forward_returns(self,daily_ret, cacl_rebal_dates, trade_date,interval='1M', shift_offset='1D',rank_only='False'):  
        cacl_dates=cacl_rebal_dates.copy()
        df_ret=daily_ret.copy()
        df_ret_comp=df_ret.loc[df_ret['date'].isin(cacl_dates['date_trade']),['date','stk_bbg','Composite']]
        df_ret.dropna(inplace=True)
        df_ret_all=[]        
        for d, date in enumerate(cacl_dates.date_trade):
            start, end = get_date_interval(date, trade_date, shift_offset, interval)
    #        cacl_dates.loc[d,'start_trade']=start
    #        cacl_dates.loc[d,'end_trade']=end
            df_ret_sub = df_ret.loc[(df_ret['date']>=start) & (df_ret['date']<=end),['date','stk_bbg','PX_Return']]
            if not df_ret_sub.empty:
                df_ret_sub.loc[:,'PX_Return']=df_ret_sub.loc[:,'PX_Return']+1
                mask = df_ret_sub.groupby(['stk_bbg'])['PX_Return'].transform(mask_first).astype(bool)
                df_ret_sub = df_ret_sub.loc[mask]
                if not df_ret_sub.empty:
                    df_ret_sub['PX_Return'] = df_ret_sub.groupby(['stk_bbg'])['PX_Return'].transform(lambda x: x.cumprod() - 1)
                    df_ret_sub = df_ret_sub.groupby(['stk_bbg']).tail(1)
                    df_ret_sub['date']=date
                    df_ret_all.append(df_ret_sub)
                
        df_ret_all = pd.concat(df_ret_all, axis=0)
        df_ret_all.rename(columns={'PX_Return':'forward_return'},inplace=True)
        df_ret_all=pd.merge(df_ret_all,df_ret_comp,left_on=['date','stk_bbg'],right_on=['date','stk_bbg'])
        if rank_only:
            # df_ret_all['forward_return']=df_ret_all.groupby(['date'])['forward_return'].rank(ascending=False)
            df_ret_all['Composite']=df_ret_all.groupby(['date'])['Composite'].rank(ascending=False)
            df_ret_all['forward_return']=df_ret_all.groupby(['date'])['forward_return'].rank(ascending=False)
        df_ret_all.set_index(['date','stk_bbg'],inplace=True)
        return df_ret_all
    
    def forward_returns_bm(self,daily_ret, cacl_rebal_dates, trade_date,interval='1M', shift_offset='1D',rank_only='False'):  
        cacl_dates=cacl_rebal_dates.copy()
        df_ret=daily_ret.copy()
        df_ret_comp=df_ret.loc[df_ret['date'].isin(cacl_dates['date_trade']),['date','stk_bbg']]
        df_ret.dropna(inplace=True)
        df_ret_all=[]        
        for d, date in enumerate(cacl_dates.date_trade):
            start, end = get_date_interval(date, trade_date, shift_offset, interval)
    #        cacl_dates.loc[d,'start_trade']=start
    #        cacl_dates.loc[d,'end_trade']=end
            df_ret_sub = df_ret.loc[(df_ret['date']>=start) & (df_ret['date']<=end),['date','stk_bbg','PX_Return']]
            if not df_ret_sub.empty:
                df_ret_sub.loc[:,'PX_Return']=df_ret_sub.loc[:,'PX_Return']+1
                mask = df_ret_sub.groupby(['stk_bbg'])['PX_Return'].transform(mask_first).astype(bool)
                df_ret_sub = df_ret_sub.loc[mask]
                if not df_ret_sub.empty:
                    df_ret_sub['PX_Return'] = df_ret_sub.groupby(['stk_bbg'])['PX_Return'].transform(lambda x: x.cumprod() - 1)
                    df_ret_sub = df_ret_sub.groupby(['stk_bbg']).tail(1)
                    df_ret_sub['date']=date
                    df_ret_all.append(df_ret_sub)
                
        df_ret_all = pd.concat(df_ret_all, axis=0)
        df_ret_all.rename(columns={'PX_Return':'forward_return'},inplace=True)
        df_ret_all=pd.merge(df_ret_all,df_ret_comp,left_on=['date','stk_bbg'],right_on=['date','stk_bbg'])
        if rank_only:
            df_ret_all['forward_return']=df_ret_all.groupby(['date'])['forward_return'].rank(ascending=False)
        df_ret_all.set_index(['date','stk_bbg'],inplace=True)
        return df_ret_all
    
    def get_date_interval(self,date, trade_date, offset, interval):
        start = offset_date_by_interval(date, offset)
        end = offset_date_by_interval(start, interval)
    
        start_trade=trade_date.loc[trade_date['date'] >= start]
        if not start_trade.empty:
            start = start_trade.head(1).squeeze()
        end_trade=trade_date.loc[trade_date['date'] >= end]
        if not end_trade.empty:    
            end = end_trade.head(1).squeeze()
        elif trade_date.tail(1).squeeze() > date:
            end = trade_date.tail(1).squeeze()
    
        return start, end
    
    def offset_date_by_interval(self,date, interval):
        unit = interval[-1].upper()
        count = int(interval[:-1])
        units = {
            'D': ('days', 1),
            'W': ('weeks', 1),
            'M': ('months', 1),
            'Q': ('months', 3),
            'Y': ('years', 1)
        }
        unit_str, multiplier = units[unit]
        return date + relativedelta.relativedelta(**{unit_str: count * multiplier})
        
    def normalize_interval_specifier(self,specifier):
        # turns a single string into a one-element list
        # flattens lists of lists.
        allowed_specifier_types = (str, int)
        if isinstance(specifier, allowed_specifier_types):
            specifier_list = [specifier]
        else:
            specifier_list = specifier
        # don't want to consume generator during validation
        specifier_list_iter, specifier_list = tee(specifier_list)
    
        for s in specifier_list_iter:
            if not isinstance(s, allowed_specifier_types):
                raise TypeError(
                    'Interval specifiers must be strings, e.g. "1M".'
                    ' Got {}, type {}'.format(s, type(s)))
    
        return list(specifier_list)
    
    def calculate_ic_history(self,daily_ret,cacl_rebal_dates, trade_date, intervals, shift_offsets):
        interval_dfs = []
        for interval in intervals:
            dfs = []
            for offset in shift_offsets:
                forward_return_ranks = forward_returns(daily_ret,cacl_rebal_dates, trade_date, interval,offset,rank_only=True)
                forward_return_ranks = forward_return_ranks[['Composite','forward_return']]
    #            forward_return_ranks = forward_return_ranks[['date','stk_bbg','Composite','forward_return']]
    #            forward_return_ranks.set_index(['date','stk_bbg'],inplace=True)
                correlation_df = calculate_correlation_from_ranks(forward_return_ranks)
                correlation_df = correlation_df.rename(interval)
                dfs.append(correlation_df)
        
            ic_df = pd.concat(dfs, keys=shift_offsets)
            interval_dfs.append(ic_df)
        
        ic_history_df = pd.concat(interval_dfs, axis=1)
        ic_history_df.index = ic_history_df.index.swaplevel(0, 1)
        ic_history_df.sort_index(level=[0, 1], inplace=True)
        ic_history_df.columns.name = 'forward_return_interval'
        ic_history_df.index.names = ('date',
                                     'shift_offset')
    
        return ic_history_df
    
    def calculate_correlation_from_ranks(self,forward_return_df):
    
        def information_coefficient_fn(df):
            # we take the spearman of the ranks because the dataframe
            # may contain some NA's. This will implicitly remove the NA's
            # and rerank the ranks.
            correlation_df = df.corr(method='spearman')
            return correlation_df['Composite'].loc['forward_return']
            
        correlation_df = forward_return_df.groupby(['date']).agg(information_coefficient_fn)
        return correlation_df['Composite']
    
    def calc_return(self,universe_df, forward_return, is_cumulative=False, qspread=False):
        
        universe_df = universe_df
        return_df = forward_return.reset_index()
        # groups = (pd.merge(return_df,universe_df, 
        #                    left_on=['date', 'stk_bbg'], 
        #                    right_on=['date', 'stk_bbg'],how='left').groupby('date'))
        groups = (pd.merge(universe_df, return_df,
                           left_on=['date', 'stk_bbg'], 
                           right_on=['date', 'stk_bbg'],how='left').groupby('date'))
        
        if qspread:#spread不需 / sum(g.weight)，weight本身就有除以 N
            period_return_df = pd.DataFrame(groups.apply(lambda g: sum(g.forward_return.fillna(0) 
                                                                        * g.weight_)), 
                                             columns=['forward_return'])
        else:
            period_return_df = pd.DataFrame(groups.apply(lambda g: sum(g.forward_return.fillna(0) 
                                                                       * g.weight_) / sum(g.weight_)), 
                                            columns=['forward_return'])
    
        if is_cumulative:
            cumulative_return_df = (period_return_df + 1).cumprod() - 1
            return cumulative_return_df
        else:
            return period_return_df
    
    def get_portfolio_turnover_20190822(self,portfolio, ratio_only=False):
        port_prev = []
        if ratio_only:
            df_turnover= pd.DataFrame(columns=['date','Turnover_Ratio'])
        else:
            df_turnover= pd.DataFrame(columns=['date','ID','Action'])
        for rebalancedate in list(portfolio.index.levels[0]):
            sec_added = [sec for sec in list(portfolio.loc[rebalancedate].index) if sec not in port_prev]
            sec_removed = [sec for sec in port_prev if sec not in list(portfolio.loc[rebalancedate].index)]
            if ratio_only:
                df_turnover=df_turnover.append({'date':rebalancedate,
                                                'Turnover_Ratio': (len(sec_added)+len(sec_removed))*0.5/len(port_prev) if len(port_prev)>0 else 0.5},
                                              ignore_index=True)
                port_prev = list(portfolio.loc[rebalancedate].index)
            else:
                for sec in sec_added:
                    df_turnover=df_turnover.append({'date':rebalancedate,'ID':sec,'Action':'added'},ignore_index=True)
                for sec in sec_removed:
                    df_turnover=df_turnover.append({'date':rebalancedate,'ID':sec,'Action':'removed'},ignore_index=True)
            port_prev = list(portfolio.loc[rebalancedate].index)
        return df_turnover.set_index('date')
    
    def get_portfolio_turnover(self,portfolio, ratio_only=False):
        port_prev = []
        if ratio_only:
            df_turnover= pd.DataFrame(columns=['date','Turnover_Ratio'])
        else:
            df_turnover= pd.DataFrame(columns=['date','ID','Action','Weight'])
        for rebalancedate in list(portfolio.index.levels[0]):
            sec_added = [sec for sec in list(portfolio.loc[rebalancedate].index) if sec not in port_prev]
            sec_removed = [sec for sec in port_prev if sec not in list(portfolio.loc[rebalancedate].index)]
            if ratio_only:
                df_turnover=df_turnover.append({'date':rebalancedate,
                                                'Turnover_Ratio': (len(sec_added)+len(sec_removed))*0.5/len(port_prev) if len(port_prev)>0 else 0.5},
                                              ignore_index=True)
                port_prev = list(portfolio.loc[rebalancedate].index)
            else:
                for sec in sec_added:
                    df_turnover=df_turnover.append({'date':rebalancedate,'ID':sec,'Action':'added'},ignore_index=True)
                for sec in sec_removed:
                    df_turnover=df_turnover.append({'date':rebalancedate,'ID':sec,'Action':'removed'},ignore_index=True)
            port_prev = list(portfolio.loc[rebalancedate].index)
        return df_turnover.set_index('date')
    
    # Benchmarkequity issuance
    def get_returns_Benchmark(self,df_returns,index,cacl_rebal_dates):    
        Benchmark_avg_return = df_returns['forward_return'].mean()
        Benchmark_cum_return = ((df_returns['forward_return'] + 1).cumprod() - 1).tail(1).squeeze()
        Benchmark_sharpe_ratio = (Benchmark_avg_return/df_returns['forward_return'].std())
        Benchmark_hit_rate = len([i for i in df_returns['forward_return'] if i > 0])/len(cacl_rebal_dates)
        Benchmark_MDD = self.max_dd(df_returns.forward_return)
    #    df_returns.reset_index(inplace=True)
        # Yearly Return
    #    df_returns['year']=df_returns.date.dt.year
        df_returns['year']=df_returns.index.levels[0].year
        Benchmark_year_returns = pd.DataFrame(df_returns.groupby('year').apply(lambda g: (g.forward_return.fillna(0)+1).cumprod() - 1)).reset_index().groupby('year').tail(1)
        df_returns['year_month']=df_returns.index.levels[0].to_period('M')
    #    df_returns['year_month']=pd.to_datetime(df_returns['date']).dt.to_period('M')
        Benchmark_pr_returns = pd.DataFrame(df_returns.groupby('year_month').apply(lambda g: (g.forward_return.fillna(0)+1).cumprod() - 1)).reset_index().groupby('year_month').tail(1)
    
        Benchmark_pr_returns=Benchmark_pr_returns.loc[:,['year_month','forward_return']]
        Benchmark_pr_returns.columns=['year_month', index]
        Benchmark_pr_returns.reset_index(drop=True, inplace=True)
        Benchmark_year_returns=Benchmark_year_returns.loc[:,['year','forward_return']]
        Benchmark_year_returns.columns = ['year', index]
        Benchmark_year_returns.reset_index(drop=True, inplace=True)
    
        Benchmark_dict=OrderedDict()
        Benchmark_dict['Factor']=index
        Benchmark_dict['Avg Return']=Benchmark_avg_return
        Benchmark_dict['Cul Return']=Benchmark_cum_return
        Benchmark_dict['Sharpe']=Benchmark_sharpe_ratio
        Benchmark_dict['MDD']=Benchmark_MDD
        Benchmark_dict['turnover']=0
        Benchmark_dict['Hit Rate']=Benchmark_hit_rate
        Benchmark_dict['Avg IC']=0   
        Benchmark_results=pd.DataFrame(Benchmark_dict,index=[0]).round(4)
    
    #    Benchmark_results=pd.DataFrame({'Factor':index,
    #                                'Avg Return':Benchmark_avg_return,
    #                                'Cul Return':Benchmark_cum_return,
    #                                'Sharpe': Benchmark_sharpe_ratio,
    #                                'MDD': Benchmark_MDD,
    #                                'turnover': 0,
    #                                'Hit Rate':Benchmark_hit_rate,
    #                                'Avg IC': 0}, index=[0]).round(4)
        
        return Benchmark_results,Benchmark_pr_returns,Benchmark_year_returns
    
    def max_dd(self,returns):
        r=returns.add(1).cumprod()
        dd=r.div(r.cummax()).sub(1)
    #     mdd = dd.min
        mdd = dd.min()
    #    end = dd.argmin()
    #     start = r.loc[:end].argmax()
    #    start = r.loc[:end].sort_index(ascending=False).argmax()
    #     return mdd, start, end
        return mdd
    
    def normalize(self,df):
        # normalize to 0~1
        result = df.copy()
    #     for feature_name in df.columns:
    #         max_value = df[feature_name].max()
    #         min_value = df[feature_name].min()
    #         result[feature_name] = (df[feature_name] - min_value) / (max_value - min_value)
    
        max_value = df.max()
        min_value = df.min()
        result = (df - min_value) / (max_value - min_value)
        return result
    
    def wavg(self,group, avg_name, weight_name):
        d = group[avg_name]
        w = group[weight_name]
        # print(group[weight_name])
        # print((d * w).sum() / w.sum())
        try:
            return (d * w).sum() / w.sum()
        except ZeroDivisionError:
            return d.mean()
    
    def winsorize(self,data, cutoff=None, replace_with_cutoff=True):
        return _transform_outliers(data, cutoff, replace_with_cutoff=replace_with_cutoff, method='winsorize')
    
    def _transform_outliers(self,data, cutoff, replace_with_cutoff, method):
        df = data.copy()  # To not overwrite data make a copy
    
        def _transform_outliers_sub(data, cutoff, replace_with_cutoff, method='trim'):
            if not isinstance(data, pd.Series):
                raise ValueError('Make sure that you are applying winsorize to a pandas dataframe or series.')
            if isinstance(cutoff, dict):
                # calculate cutoff values
                if 'quantile' in cutoff:
                    q = data.quantile(cutoff['quantile'])
                elif 'std' in cutoff:
                    std = [data.mean()-data.std()*cutoff['std'][0], data.mean()+data.std()*cutoff['std'][1]]
                    q = pd.Series(index=cutoff['std'], data=std)
                # if replace_with_cutoff is false, replace with true existing values closest to cutoff
                if method == 'winsorize':
                    if not replace_with_cutoff:
                        q.iloc[0] = data[data > q.iloc[0]].min()
                        q.iloc[1] = data[data < q.iloc[1]].max()
            else:
                raise ValueError('cutoff must be a dictionary with quantile or std keys.')
            if method == 'winsorize':
                if isinstance(q, pd.Series) and len(q) == 2:
                    data[data < q.iloc[0]] = q.iloc[0]
                    data[data > q.iloc[1]] = q.iloc[1]
            elif method == 'trim':
                data[data < q.iloc[0]] = np.nan
                data[data > q.iloc[1]] = np.nan
            return data
    
        # transform each column if a dataframe, if series just transform data
        if isinstance(df, pd.DataFrame):
            for col in df.columns:
                df.loc[:, col] = _transform_outliers_sub(df.loc[:, col], cutoff=cutoff, replace_with_cutoff=replace_with_cutoff, method=method)
            return df
        elif isinstance(df, pd.Series):
            return _transform_outliers_sub(df, cutoff=cutoff, replace_with_cutoff=replace_with_cutoff, method=method)
        else:
            raise ValueError('Data must be a pandas DataFrame or Series')
            
    
    def create_quantile_portfolios(self,factor_df, n_quantiles, currency):
    #"""Column labels for use in bqfactor"""
    #
    #BQL_ID_DATE = 'ID_DATE'
    #DATE_COL = 'date'
    #WEIGHT_COL = 'weight'
    #FORWARD_RETURN_COL = 'forward_return'
    #FORWARD_RETURN_START_COL = 'start_date'
    #FORWARD_RETURN_END_COL = 'end_date'
    #FORWARD_RETURN_RANK_COL = FORWARD_RETURN_COL + '_rank'
    #FACTOR_COL = 'factor'
    #FACTOR_DATE_LABEL = 'factor_date'
    #FACTOR_RANK_COL = FACTOR_COL + '_rank'
    #FORWARD_RETURN_DATE_COL = 'return_date'
    #FORWARD_RETURN_DATE_COL_BQL = 'DATE'
    #FORWARD_RETURN_INTERVAL_LABEL = 'forward_return_interval'
    #SECURITY_LABEL = 'security'
    #SHIFT_OFFSET_LABEL = 'shift_offset'
    #QUANTILE_COL_LABEL = 'quantile'
    
        def assign_quantiles(snapshot_series):
            return pd.qcut(snapshot_series,
                           n_quantiles,
                           labels=False)
    
        factor_df_clean = factor_df.dropna()
        quantiles = factor_df_clean.groupby(level='factor_date')
        quantile_df = quantiles.transform(assign_quantiles)
        quantile_df.columns = ['quantile']
    
        quantile_pfs = []
    
        combined_df = pd.concat([factor_df_clean, quantile_df], axis=1)
    #    combined_df['weight'] = 1.0
        combined_df.index = combined_df.index.copy()
        combined_df.index.levels[0].name = 'date'   # for bqport.new_portfolio
    
        for quantile, df in combined_df.groupby('quantile'):
            quantile_pfs.append(df)
    
        return quantile_pfs
    
    def create_factor_portfolio(self,high_pf, low_pf,currency):
        long_pf={}
        for date, df in high_pf.groupby('date'):
            long_pf_sub={}
            for sec, df1 in df.groupby('stk_bbg'):
                df1.reset_index(inplace=True,drop=True)
                long_pf_sub[sec]=df1
            long_pf[date]=long_pf_sub
        
            
        short_pf={}
        for date, df in low_pf.groupby('date'):
            short_pf_sub={}
            for sec, df1 in df.groupby('stk_bbg'):
                df1.reset_index(inplace=True,drop=True)
                short_pf_sub[sec]=df1
            short_pf[date]=short_pf_sub
            
        dates_L = list(long_pf.keys())
        dates_S = list(short_pf.keys())
        
        final_weights_dict = {}
        #
        for date in dates_L:
            final_weights_dict[date] = {}
            positions = long_pf[date]
            weights_dict = {security: positions[security].weight_[0]
                            for security in positions
                            if positions[security].weight_[0] > 0.0}
            weights_dict_normalized = normalize_weights(weights_dict)
            for security, weight in weights_dict_normalized.items():
                final_weights_dict[date][security] = weight
                
        
        for date in dates_S:
            if date not in final_weights_dict:
                final_weights_dict[date] = {}
        
            positions = short_pf[date]
            weights_dict = {security: positions[security].weight_[0]
                            for security in positions
                            if positions[security].weight_[0] > 0.0}
            weights_dict_normalized = normalize_weights(weights_dict)
            for security, weight in weights_dict_normalized.items():
                if security in final_weights_dict[date]:
                    raise ValueError(
                        "Security {} found in top and bottom quantile"
                        .format(security))
                final_weights_dict[date][security] = -weight
        
        for date in sorted(final_weights_dict.keys()):
            final_weights_dict[date] = adjust_cash_for_leverage(
                final_weights_dict[date],
                currency + ' Curncy', 1.0)
            final_weights_dict[date] = normalize_weights(
                final_weights_dict[date],
                normalize_to=1.0)
        
        weights_dfs = []
        
        rebalance_dates = list(sorted(final_weights_dict.keys()))
        
        for date in rebalance_dates:
            date_df = pd.DataFrame(data={'weight_': final_weights_dict[date]})
            weights_dfs.append(date_df)
        
        weights_df = pd.concat(weights_dfs, keys=pd.to_datetime(rebalance_dates))
        weights_df.index = weights_df.index.copy()
        # pd.MultiIndex.from_product(weights_df, names=['date', 'stk_bbg'])
        weights_df.index.set_names(['date', 'stk_bbg'], inplace=True)
        # weights_df.index.levels[0].name = 'date'
        # weights_df.index.levels[1].name = 'stk_bbg'
        return weights_df
    
    def adjust_cash_for_leverage(self,weights, cash_asset, leverage_ratio):
        """Adjusts a 'cash_asset's positions to achieve a `leverage_ratio`
    
        Parameters
        ----------
        weights : Mapping of Securities to weights
            The current set of weights.
        cash_asset: Security
            the cash asset for which to change the weight to target a leverage ratio
        leverage_ratio: float
            the target leverage ratio
    
        Returns
        -------
        weights : dict of new weights with desired leverage_ratio
    
        Notes
        -----
        leverage_ratio is defined as:
    
                 L =  gross_exposure / (net_exposure + cash)
    
        , where  gross_exposure = sum(long positions) + sum(short positions)
        and        net_exposure = sum(long_positions) - sum(short positions)
    
        Therefore,
              cash = (gross_exposure / L) - net_exposure
    
        """
        if not leverage_ratio > 0:
            raise ValueError("Leverage ratio must be greater than 0! Got {}"
                             .format(leverage_ratio))
    
        gross_exposure = sum(abs(weight)
                             for security, weight in weights.items()
                             if security != cash_asset)
        net_exposure = sum(weight
                           for security, weight in weights.items()
                           if security != cash_asset)
    
        required_net_exposure = gross_exposure / leverage_ratio
        additional_capital_required = required_net_exposure - net_exposure
    
        adjusted_weights = dict(weights)
        if additional_capital_required:
            adjusted_weights[cash_asset] = additional_capital_required
        return adjusted_weights
    
    
    def normalize_weights(self,weights_dict, normalize_to=100):
        """Normalizes a dict of weights to a value
    
        Parameters
        ----------
        weights_dict : Mapping from keys to weights
        normalize_to : Value to normalize weights to (default: 100)
    
        Returns
        -------
        normalized_dict : Mapping from keys to normalized weights
        """
    
        try:
            total = sum(weights_dict.values())
        except TypeError:
            raise TypeError("Values of weights must be numeric. Got {}"
                            .format(list(weights_dict.values())))
        except AttributeError:
            raise TypeError(
                "First argument must be a dict/mapping with numeric values. Got {}"
                .format(weights_dict))
        else:
            if total == 0.0:
                raise ValueError("Sum of weights must not be zero. Got {}"
                                 .format(total))
            return {k: normalize_to * v / total
                    for k, v in weights_dict.items()}
    
    
    
    def calculate_adjusted_prices(self,df, column_c, column_r):
        """ Vectorized approach for calculating the adjusted prices for the
        specified column in the provided DataFrame. This creates a new column
        called 'adj_<column name>' with the adjusted prices. This function requires
        that the DataFrame have columns with dividend and split_ratio values.
    
        :param df: DataFrame with raw prices along with dividend and split_ratio
            values
        :param column: String of which price column should have adjusted prices
            created for it
        :return: DataFrame with the addition of the adjusted price column
        """
        adj_column = 'adj_' + column_c
    
        # Reverse the DataFrame order, sorting by date in descending order
        df.sort_index(ascending=False, inplace=True)
    
        price_col = df[column_c].values
        ret_col = df[column_r].values
        adj_price_col = np.zeros(len(df.index))
        adj_price_col[0] = price_col[0]
    
        for i in range(1, len(price_col)):
            adj_price_col[i] = round(adj_price_col[i - 1] / (1 + ret_col[i - 1]), 6)
            # adj_price_col[i] = adj_price_col[i - 1] / (1 + ret_col[i - 1])
        df[adj_column] = adj_price_col
    
        # Change the DataFrame order back to dates ascending
        df.sort_index(ascending=True, inplace=True)
    
        return df
    
    #def calc_beta(df):
    #    np_array = df.values
    #    s = np_array[:,0] # stock returns are column zero from numpy array
    #    m = np_array[:,1] # market returns are column one from numpy array
    #    covariance = np.cov(s,m) # Calculate covariance between stock and market
    #    beta = (covariance[0,1]/covariance[1,1])/np_array[0,0]
    #    return beta
    #
    #def rolling_apply(df, period, func, min_periods=None):
    #    if min_periods is None:
    #        min_periods = period
    #    result = pd.Series(np.nan, index=df.index)
    #    
    #    for i in range(1, len(df)+1):
    #        sub_df = df.iloc[max(i-period, 0):i,:] #I edited here
    #        if len(sub_df) >= min_periods:
    #            idx = sub_df.index[-1]
    #            result[idx] = func(sub_df)
    #    return result
    #
    #
    #def roll(df, w):
    #    # stack df.values w-times shifted once at each stack
    #    roll_array = np.dstack([df.values[i:i+w, :] for i in range(len(df.index) - w + 1)]).T
    #    # roll_array is now a 3-D array and can be read into
    #    # a pandas panel object
    #    panel = pd.Panel(roll_array, 
    #                     items=df.index[w-1:],
    #                     major_axis=df.columns,
    #                     minor_axis=pd.Index(range(w), name='roll'))
    #    # convert to dataframe and pivot + groupby
    #    # is now ready for any action normally performed
    #    # on a groupby object
    #    return panel.to_frame().unstack().T.groupby(level=0)
    #
    #def beta(df):
    #    # first column is the market
    #    X = df.values[:, [0]]
    #    # prepend a column of ones for the intercept
    #    X = np.concatenate([np.ones_like(X), X], axis=1)
    #    # matrix algebra
    #    b = np.linalg.pinv(X.T.dot(X)).dot(X.T).dot(df.values[:, 1:])
    #    return pd.Series(b[1], df.columns[1:], name='Beta')
    
    def rwindows(self,a, window):
        if a.ndim == 1:
            a = a.reshape(-1, 1)
        shape = a.shape[0] - window + 1, window, a.shape[-1]
        strides = (a.strides[0],) + a.strides
        windows = np.lib.stride_tricks.as_strided(a, shape=shape, strides=strides)
        return np.squeeze(windows)
    
    def factor_cov_matrix(self,factor_returns, ann_factor):
        """
        Get the factor covariance matrix
    
        Parameters
        ----------
        factor_returns : DataFrame
            Factor returns
        ann_factor : int
            Annualization factor
    
        Returns
        -------
        factor_cov_matrix : DataFrame
            Factor covariance matrix
        """
        
        #TODO: Implement function
        
        return np.diag(factor_returns.var(axis=0,ddof=1)*ann_factor)
    
    def idiosyncratic_var_matrix(self,returns, factor_returns, factor_betas, ann_factor):
        """
        Get the idiosyncratic variance matrix
    
        Parameters
        ----------
        returns : DataFrame
            Returns for each ticker and date
        factor_returns : DataFrame
            Factor returns
        factor_betas : DataFrame
            Factor betas
        ann_factor : int
            Annualization factor
    
        Returns
        -------
        idiosyncratic_var_matrix : DataFrame
            Idiosyncratic variance matrix
        """
        
        #TODO: Implement function
        common_returns_=pd.DataFrame(np.dot(factor_returns,factor_betas.T),returns.index,returns.columns)
        residuals_=returns-common_returns_
        return pd.DataFrame(np.diag(np.var(residuals_))*ann_factor,returns.columns,returns.columns)
    
    def idiosyncratic_var_vector(self,returns, idiosyncratic_var_matrix):
        """
        Get the idiosyncratic variance vector
    
        Parameters
        ----------
        returns : DataFrame
            Returns for each ticker and date
        idiosyncratic_var_matrix : DataFrame
            Idiosyncratic variance matrix
    
        Returns
        -------
        idiosyncratic_var_vector : DataFrame
            Idiosyncratic variance Vector
        """
        
        #TODO: Implement function
        
        return pd.DataFrame(np.diagonal(idiosyncratic_var_matrix), returns.columns)
    
    
    def predict_portfolio_risk(self,factor_betas, factor_cov_matrix, idiosyncratic_var_matrix, weights):
        """
        Get the predicted portfolio risk
        
        Formula for predicted portfolio risk is sqrt(X.T(BFB.T + S)X) where:
          X is the portfolio weights
          B is the factor betas
          F is the factor covariance matrix
          S is the idiosyncratic variance matrix
    
        Parameters
        ----------
        factor_betas : DataFrame
            Factor betas
        factor_cov_matrix : 2 dimensional Ndarray
            Factor covariance matrix
        idiosyncratic_var_matrix : DataFrame
            Idiosyncratic variance matrix
        weights : DataFrame
            Portfolio weights
    
        Returns
        -------
        predicted_portfolio_risk : float
            Predicted portfolio risk
        """
        assert len(factor_cov_matrix.shape) == 2
        
        #TODO: Implement function
        
        return np.sqrt(weights.T.dot(factor_betas.dot(factor_cov_matrix.dot(factor_betas.T)) + idiosyncratic_var_matrix).dot(weights)).iloc[0][0]
    
    
    def tracking_error(self,benchmark_returns_by_date, etf_returns_by_date):
        """
        Calculate the tracking error.
    
        Parameters
        ----------
        benchmark_returns_by_date : Pandas Series
            The benchmark returns for each date
        etf_returns_by_date : Pandas Series
            The ETF returns for each date
    
        Returns
        -------
        tracking_error : float
            The tracking error
        """
        assert benchmark_returns_by_date.index.equals(etf_returns_by_date.index)
        
        #TODO: Implement function
    
        return np.sqrt(252) * np.std(etf_returns_by_date - benchmark_returns_by_date, ddof=1)
    
    
    def get_portfolio_turnover_weight(self,portfolio):
        port_chg = []
        port_prev = pd.DataFrame()
        df_turnover= pd.DataFrame(columns=['date','weight_chg'])
        sec_weight=[]
        for rebalancedate in list(portfolio.index.unique()):
            port_now = portfolio.loc[rebalancedate]
            if not port_prev.empty:            
                port_chg=port_now.merge(port_prev, on=['stk_bbg', 'CRNCY'], how='outer', suffixes=('x', 'y'))
                port_chg.fillna(value=0, inplace=True)
                port_chg['weight_chg'] = port_chg['weight_x'] - port_chg['weight_y']
                port_chg['date']=rebalancedate
            else:
                port_chg=port_now
                port_chg.fillna(value=0, inplace=True)
                port_chg['weight_chg'] = port_chg['weight_']
                port_chg['date']=rebalancedate            
            port_chg=port_chg[['date','CRNCY','weight_chg']]
            port_chg.sort_values(by=['weight_chg'],inplace=True)
            df_turnover=df_turnover.append({'date':rebalancedate,'weight_chg': (port_chg['weight_chg'].abs().sum())/2}, ignore_index=True)
            port_prev = port_now        
            sec_weight.append(port_chg)
        sec_weight = pd.concat(sec_weight, axis=0)
        sec_weight.reset_index(inplace=True)
        sec_weight=sec_weight.loc[(sec_weight!=0).any(axis=1)]
        df_turnover.set_index('date',inplace=True)
        return df_turnover, sec_weight
    
    def GetBeta(self,factor_data, stock_return):
        regr = linear_model.LinearRegression()
        regr.fit(np.transpose(np.matrix(factor_data)), np.transpose(np.matrix(stock_return)))
        return regr.coef_
    
    def GetResiduals(self,stock,enddate):
        Xinput = [EquityOCFP(stock,enddate), EquitySize(stock,enddate), RSIIndividual(stock,enddate), Min130Day(stock,enddate)]
        X = pd.concat(Xinput, axis=1)
        date = enddate
        tempprice = get_price(list(AllStock), date, "{:%Y-%m-%d}".format(datetime.datetime.strptime(date, '%Y-%m-%d') + datetime.timedelta(days=30)), frequency='1d', fields=None, adjusted=True)['OpeningPx']
        y = np.log(tempprice.iloc[-1]/tempprice.iloc[0])
        DataAll = pd.concat([X,y],axis = 1)
        DataAll = DataAll.dropna()
        regr = linear_model.LinearRegression()
        regr.fit(np.matrix(DataAll.ix[:,0:4]), np.transpose(np.matrix(DataAll.ix[:,4])))
        residuals = regr.predict(np.matrix(DataAll.ix[:,0:4])) - np.transpose(np.matrix(DataAll.ix[:,4]))
        residuals = pd.DataFrame(data = residuals, index = np.transpose(np.matrix(DataAll.index.values)))
        residuals.index = DataAll.index.values
        residuals.columns = [enddate]
        return residuals
    
    
    def performance(self,signal_data,trade_dates_start,date_map,df_index,portfolio_1,*args):
        performance_set=args[0]
        para = args[1]       
        signal_data.sort_values(by=['date','signal','indicator'],ascending=[True,False,False],inplace=True)
        hold_portfolio=[]
        trade = []
        count_stop_loss = 0
        stock_pool = signal_data['stk_bbg'].unique()
        trade_col_name = ['p_w','c_t_1','t_shares','o_t','p_t','t_amt']
        cor_act_col_name = ['Adj_Factor_rev','DVD','t']
        holdings_col_name = ['shares','px','cost','px_m','mv','unreal_pl','ret','dvd','real_pl','tlt_pl']
        holdings = pd.DataFrame(index=stock_pool,columns = holdings_col_name + trade_col_name + cor_act_col_name, data=0)
        holdings.index.name = 'stk_bbg'
        perf_col_name = ['unreal_pl','real_pl','dvd','cost','mv','tlt_pl']
        ret_col_name = ['p_ret','b_ret','p_ret_cul','b_ret_cul']
        ret_col_name_add = ['b_O','b_L']
        performance = pd.DataFrame(index=trade_dates_start.date,columns = perf_col_name + ret_col_name + ret_col_name_add, data=0)
        ret_tlt_col_name = ['ret','vol','r/v','max_ret','min_ret','turn_over','MDD']
        performance_tlt=pd.DataFrame(index=['p','b'],columns = ret_tlt_col_name,data=0)
        turnover = 0
        # 先找出第一個交易日的前日收盤價
        px_prev = pd.DataFrame(index=stock_pool,columns=['px_m'],data=0)
        t_1 = date_map.loc[date_map['date_trade']==trade_dates_start.date[0],'date_trade_last']
        signal_data['PX_LAST_fill'] = signal_data.groupby('stk_bbg')['PX_LAST'].fillna(method='ffill')
        holdings['px_m'] = signal_data.loc[signal_data['date']==t_1[0],['stk_bbg','PX_LAST_fill']].set_index('stk_bbg')
        holdings['px_m'].fillna(0,inplace=True)
        df_stop_loss= pd.DataFrame(index=stock_pool,columns = ['stp_loss'], data=0)
        for d, date in enumerate(trade_dates_start.date):
            # 如果被併購或下市(最後一個交易日)，出清持股(交易策略計算訊號時已考慮)
            signal_t = signal_data.loc[signal_data['date']==date]
            holdings['t'] = signal_t.set_index('stk_bbg')['t']
            # 如果達到停損，設定訊號為0-------------
            stop_loss_stock = holdings.loc[(holdings['ret']<para[1]) & (holdings['t']==1),].index
            count_stop_loss = count_stop_loss + len(stop_loss_stock)
            # 停損後N天不能買
            df_stop_loss.loc[df_stop_loss.index.isin(stop_loss_stock),'stp_loss'] = para[3]
            stop_loss_stock = df_stop_loss.loc[df_stop_loss['stp_loss']>0,].index
            signal_t.loc[signal_t['stk_bbg'].isin(stop_loss_stock),'signal'] = 0        
            df_stop_loss.loc[df_stop_loss['stp_loss']>0,'stp_loss']=df_stop_loss.loc[df_stop_loss['stp_loss']>0,'stp_loss']-1 
            # 如果達到停損，設定訊號為0-------------
            n_1=0    
            portfolio_hold = portfolio_1['stk_bbg'] 
            portfolio_hold=pd.merge(portfolio_hold,signal_t[['date','stk_bbg','signal','indicator','t']],on=['stk_bbg'],how='left')
            portfolio_hold['signal'].fillna(0,inplace=True)
            portfolio_hold['date'].fillna(date,inplace=True)
            portfolio_hold.sort_values(['signal','indicator'],ascending=[False,False],inplace=True)
            portfolio_hold.reset_index(inplace=True,drop=True)
            hold_num = len(portfolio_hold)
            portfolio_others = signal_t.loc[~signal_t['stk_bbg'].isin(portfolio_hold['stk_bbg']),['date','stk_bbg','signal','indicator','t']]
            portfolio_others.sort_values(['signal','indicator'],ascending=[False,False],inplace=True)  

            portfolio_others = portfolio_others.reset_index(drop=True)
            
            if hold_num < para[0]:
                new_hold = portfolio_others.iloc[0:int(para[0]-hold_num),]
                new_hold = new_hold.loc[new_hold['t']<2,]
                # portfolio_hold=portfolio_hold.append(new_hold)
                portfolio_hold = pd.concat([portfolio_hold, new_hold], ignore_index=True)
                portfolio_hold.reset_index(drop=True,inplace=True)
                portfolio_others = signal_t.loc[~signal_t['stk_bbg'].isin(portfolio_hold['stk_bbg']),['date','stk_bbg','signal','indicator','t']]
                portfolio_others.sort_values(['signal','indicator'],ascending=[False,False],inplace=True)
                portfolio_others = portfolio_others.reset_index(drop=True)
            if len(portfolio_hold)>0:
                for i, ind in enumerate(portfolio_others.indicator):
                    for i_h in range(n_1, len(portfolio_hold)):
                        if (portfolio_hold.loc[i_h,'t']<2) and (portfolio_others.loc[i,'t']<2):
                            if (ind-portfolio_hold.loc[i_h,'indicator']>para[2] or portfolio_hold.loc[i_h,'signal']<=0) and portfolio_others.loc[i,'signal'] > 0:
                                for i_j in range(len(portfolio_hold)-1,i_h, -1):
                                    portfolio_hold.loc[i_j,:]=portfolio_hold.loc[i_j-1,:]                           
                                portfolio_hold.loc[i_h,:]=portfolio_others.loc[i,:]
                                n_1 = i_h + 1
                                break
                    if i_h == len(portfolio_hold) - 1:
                        break
        
            hold_num = len(portfolio_hold)
            portfolio_1 = portfolio_hold.loc[portfolio_hold['signal']>0,]
            if not portfolio_1.empty:
                hold_portfolio.append(portfolio_1)  
            # 找出當期持股，------------------      
            # 當日市價、合併分割與股利資料
            px_prev = pd.DataFrame(holdings['px_m'])
            holdings[cor_act_col_name] = 0
            holdings[['o_t','px_m','vol','Adj_Factor_rev','DVD','t']] = signal_t[['stk_bbg','PX_OPEN','PX_LAST','PX_VOLUME','Adj_Factor_rev','DVD','t']].set_index('stk_bbg')
            holdings['DVD'].fillna(0,inplace=True)
            holdings['Adj_Factor_rev'].fillna(1,inplace=True)
            holdings['t'].fillna(2,inplace=True)
            # 處裡分割(股數與庫存成本)
            holdings['shares'] = holdings['shares']* holdings['Adj_Factor_rev']
            holdings['px'] = holdings['cost']/ holdings['shares']
            # 處理股利(前一天市值乘上股利率)
            holdings['dvd'] = holdings['dvd'] + holdings['mv'] * holdings['DVD']*(1-performance_set[4])
            # # 合併最新權重
            holdings['p_w_1'] = holdings['p_w']
            holdings['p_w'] = 0
            holdings.loc[portfolio_1['stk_bbg'],'p_w'] = 1/para[0]
            holdings['p_w_1'] = holdings['p_w']-holdings['p_w_1']
            if abs(holdings['p_w_1']).sum()>0:
                # 買進
                holdings['t_shares'] = round(holdings['p_w_1']*performance_set[0]/px_prev['px_m']/performance_set[5],0)*performance_set[5]
                # # 實際交易情況
                holdings['p_t']=(holdings['o_t'] + holdings['px_m'])/2
                holdings['t_shares'].fillna(0,inplace=True)
                # 若當天有分割，要處裡股數
                holdings['t_shares'] = holdings['t_shares'] * holdings['Adj_Factor_rev']          
                # 全數賣出(賣出不用處裡分割股數)
                holdings.loc[holdings['p_w_1']<0,'t_shares'] = -holdings['shares']
                # 交易金額
                holdings['t_amt']=holdings['t_shares'] * holdings['p_t']
                holdings.loc[holdings['t_shares'] > 0 , 't_amt'] = holdings['t_amt']*(1+performance_set[1]+performance_set[2])
                holdings.loc[holdings['t_shares'] < 0 , 't_amt'] = holdings['t_amt']*(1-performance_set[1]-performance_set[2]-performance_set[3])
                turnover = turnover + abs(holdings['t_amt']).sum()
                df_trade = holdings.loc[holdings['t_shares']!=0,['t_shares','t_amt']]
                df_trade['date'] = date
                df_trade.reset_index(inplace=True)
                df_trade.set_index('date',inplace=True, drop=True)
                if not df_trade.empty:
                    trade.append(df_trade)                       
                # # 滾入庫存
                # # 庫存股數
                holdings['shares'] = holdings['shares'] + holdings['t_shares']
                # # 庫存成本
                # # 如果是買單，直接加入庫存成本
                holdings.loc[holdings['t_shares'] > 0 , 'cost'] = holdings['cost'] + holdings['t_amt']  
                # # # 如果是賣單，用均價從庫存成本扣除   僅適用於非全數賣出，全數賣出則出清
                holdings.loc[holdings['t_shares'] < 0 , 'cost'] = holdings['cost'] + holdings['t_shares']*holdings['px']
                # # 如果全數賣出，庫存成本歸零
                holdings.loc[holdings['shares']==0,'cost'] = 0
                # # 如果是賣單，計算已實現損益
                holdings.loc[holdings['t_shares'] < 0 , 'real_pl'] = holdings['real_pl'] + (-holdings['t_amt']+holdings['t_shares']*holdings['px'])
                # # 重算庫存成本
                holdings['px'] = holdings['cost'] / holdings['shares']
            # # 如果沒有市價，可能是停牌，因此補前日資料
            holdings.loc[holdings['px_m'].isnull(),'px_m'] = px_prev['px_m']    
            # 重算市值
            holdings['mv'] = holdings['px_m'] * holdings['shares']
            # 重算未實現損益
            holdings['unreal_pl'] = holdings['mv'] - holdings['cost']
            # # 重算報酬率
            holdings['ret'] = holdings['unreal_pl']/holdings['cost'] 
            # # 重算總損益
            holdings.fillna(0,inplace=True)
            holdings['tlt_pl'] = holdings['unreal_pl'] + holdings['real_pl'] + holdings['dvd'] 
            # 績效表現彙總
            for i in (perf_col_name):
                performance.loc[date, i] = holdings[i].sum()
        # 計算報酬率
        performance['p_ret'] = (performance['tlt_pl']-performance['tlt_pl'].shift(1))/(abs(performance['mv'].shift(1)))
        performance[['b_ret','b_O','b_L']] = df_index.loc[df_index['date'].isin(trade_dates_start.date),['date','PX_Return','PX_OPEN','PX_LAST']].set_index(['date'])
        
        # performance.loc[performance['cost'].shift(1)==0,['p_ret','b_ret']] = 0
        # performance.loc[performance.index<=performance['cost'].ne(0).idxmax(),['p_ret','b_ret']] = 0
        # performance.loc[(performance['cost'].shift(periods=2,fill_value=0)==0) & (performance['cost'].shift(1)>0),'p_ret'] = (performance['tlt_pl']-performance['tlt_pl'].shift(periods=2,fill_value=0))/(performance['mv'].shift(1))
        # performance.loc[(performance['cost'].shift(periods=2,fill_value=0)==0) & (performance['cost'].shift(1)>0),'b_ret'] = (performance['b_L']-((performance['b_O'].shift(1)+performance['b_L'].shift(1))/2))/((performance['b_O'].shift(1)+performance['b_L'].shift(1))/2)   
        
        performance.loc[performance['cost'].shift(1)==0,'p_ret'] = (performance['tlt_pl']-performance['tlt_pl'].shift(1))/performance['cost']
        performance.loc[(performance['cost']==0) & (performance['cost'].shift(1)==0),'p_ret'] = 0
        performance.loc[performance.index<=performance['cost'].ne(0).idxmax(),'p_ret'] = performance['tlt_pl']/performance['cost']
        performance.loc[performance.index<=performance['cost'].ne(0).idxmax(),'b_ret'] = (performance['b_L']-((performance['b_O']+performance['b_L'])*0.5))/((performance['b_O']+performance['b_L'])*0.5)
        
        
        
        performance['p_ret_cul'] = ((performance['p_ret']+1).cumprod())
        performance['b_ret_cul'] = ((performance['b_ret']+1).cumprod())
        performance = performance.loc[:,perf_col_name + ret_col_name]
        performance_year=performance.loc[performance.groupby(performance.index.year).tail(1).index,['p_ret_cul','b_ret_cul']]
        performance_year['p_ret'] = (performance_year['p_ret_cul']/performance_year['p_ret_cul'].shift(1))-1
        performance_year['b_ret'] = (performance_year['b_ret_cul']/performance_year['b_ret_cul'].shift(1))-1
        performance_year.loc[performance_year.index[0],'p_ret']=performance_year.loc[performance_year.index[0],'p_ret_cul']-1
        performance_year.loc[performance_year.index[0],'b_ret']=performance_year.loc[performance_year.index[0],'b_ret_cul']-1
        performance_year['alpha']=performance_year['p_ret']-performance_year['b_ret']
        performance_tlt.loc['p','ret']=(performance['p_ret_cul'].tail(1).values)**(1/len(performance_year))-1
        if len(hold_portfolio)>0:
            hold_portfolio = pd.concat(hold_portfolio, axis=0)
            trade = pd.concat(trade, axis=0) 
        # 計算報酬率
        performance_tlt.loc['b','ret']=(performance['b_ret_cul'].tail(1).values)**(1/len(performance_year))-1
        performance_tlt.loc['p','vol']=np.std(performance['p_ret'])*(252)**(1/2)
        performance_tlt.loc['b','vol']=np.std(performance['b_ret'])*(252)**(1/2)
        performance_tlt.loc['p','r/v']=performance_tlt.loc['p','ret']/performance_tlt.loc['p','vol']
        performance_tlt.loc['b','r/v']=performance_tlt.loc['b','ret']/performance_tlt.loc['b','vol']
        performance_tlt.loc['p','max_ret']=performance['p_ret_cul'].max()-1
        performance_tlt.loc['p','min_ret']=performance['p_ret_cul'].min()-1
        performance_tlt.loc['b','max_ret']=performance['b_ret_cul'].max()-1
        performance_tlt.loc['b','min_ret']=performance['b_ret_cul'].min()-1
        NAV_avg = performance_set[0] + holdings['tlt_pl'].mean()    
        performance_tlt.loc['p','turn_over'] = (turnover/2)/NAV_avg/len(trade_dates_start)*250
        performance_tlt.loc['b','turn_over'] = 0
        performance_tlt.loc['p','MDD'] = self.max_dd(performance['p_ret'])
        performance_tlt.loc['b','MDD'] = self.max_dd(performance['b_ret'])
        performance_tlt.loc['p','stp_loss'] = count_stop_loss
        
        return performance_tlt,performance_year,performance,hold_portfolio,trade,holdings
    
    def performance_opt(self,signal_data,trade_dates_start,date_map,df_index,portfolio_1,*args):
        performance_set=args[0]
        para = args[1]

        signal_data.sort_values(by=['date','signal','indicator'],ascending=[True,False,False],inplace=True)

        count_stop_loss = 0
        stock_pool = signal_data['stk_bbg'].unique()
        trade_col_name = ['p_w','c_t_1','t_shares','o_t','p_t','t_amt']
        cor_act_col_name = ['Adj_Factor_rev','DVD','t']
        holdings_col_name = ['shares','px','cost','px_m','mv','unreal_pl','ret','dvd','real_pl','tlt_pl']
        holdings = pd.DataFrame(index=stock_pool,columns = holdings_col_name + trade_col_name + cor_act_col_name, data=0)
        holdings.index.name = 'stk_bbg'
        perf_col_name = ['unreal_pl','real_pl','dvd','cost','mv','tlt_pl']
        ret_col_name = ['p_ret','b_ret','p_ret_cul','b_ret_cul']
        ret_col_name_add = ['b_O','b_L']
        performance = pd.DataFrame(index=trade_dates_start.date[0:-1],columns = perf_col_name + ret_col_name + ret_col_name_add, data=0)
        # 先找出第一個交易日的前日收盤價
        px_prev = pd.DataFrame(index=stock_pool,columns=['px_m'],data=0)
        t_1 = date_map.loc[date_map['date_trade']==trade_dates_start.date[0],'date_trade_last']
        signal_data['PX_LAST_fill'] = signal_data.groupby('stk_bbg')['PX_LAST'].fillna(method='ffill')
        holdings['px_m'] = signal_data.loc[signal_data['date']==t_1[0],['stk_bbg','PX_LAST_fill']].set_index('stk_bbg')
        holdings['px_m'].fillna(0,inplace=True)
        df_stop_loss= pd.DataFrame(index=stock_pool,columns = ['stp_loss'], data=0)
        for d, date in enumerate(trade_dates_start.date[0:-1]):
            # if date==datetime.strptime('20140102',date_format):
            #     a=0
            # 如果被併購或下市(最後一個交易日)，出清持股(交易策略計算訊號時已考慮)
            signal_t = signal_data.loc[signal_data['date']==date]
            holdings['t'] = signal_t.set_index('stk_bbg')['t']
            # 如果達到停損，設定訊號為0-------------
            # stop_loss_stock = holdings.loc[(holdings['ret']<para[1]),].index
            stop_loss_stock = holdings.loc[(holdings['ret']<para[1]) & (holdings['t']==1),].index
            count_stop_loss = count_stop_loss + len(stop_loss_stock)
            # 停損後N天不能買
            df_stop_loss.loc[df_stop_loss.index.isin(stop_loss_stock),'stp_loss'] = para[3]
            stop_loss_stock = df_stop_loss.loc[df_stop_loss['stp_loss']>0,].index
            signal_t.loc[signal_t['stk_bbg'].isin(stop_loss_stock),'signal'] = 0        
            df_stop_loss.loc[df_stop_loss['stp_loss']>0,'stp_loss']=df_stop_loss.loc[df_stop_loss['stp_loss']>0,'stp_loss']-1 
            # 如果達到停損，設定訊號為0-------------
            n_1=0    
            portfolio_hold = portfolio_1['stk_bbg'] 
            portfolio_hold=pd.merge(portfolio_hold,signal_t[['date','stk_bbg','signal','indicator','t']],on=['stk_bbg'],how='left')
            portfolio_hold['signal'].fillna(0,inplace=True)
            portfolio_hold['date'].fillna(date,inplace=True)
            portfolio_hold.sort_values(['signal','indicator'],ascending=[False,False],inplace=True)
            portfolio_hold.reset_index(inplace=True,drop=True)
            hold_num = len(portfolio_hold)
            portfolio_others = signal_t.loc[~signal_t['stk_bbg'].isin(portfolio_hold['stk_bbg']),['date','stk_bbg','signal','indicator','t']]
            portfolio_others.sort_values(['signal','indicator'],ascending=[False,False],inplace=True)  
            portfolio_others = portfolio_others.reset_index(drop=True)
            
            if hold_num < para[0]:
                new_hold = portfolio_others.iloc[0:int(para[0]-hold_num),:]
                new_hold = new_hold.loc[new_hold['t']<2,]
                portfolio_hold = pd.concat([portfolio_hold, new_hold], ignore_index=True)
                portfolio_hold.reset_index(drop=True,inplace=True)
                portfolio_others = signal_t.loc[~signal_t['stk_bbg'].isin(portfolio_hold['stk_bbg']),['date','stk_bbg','signal','indicator','t']]
                portfolio_others.sort_values(['signal','indicator'],ascending=[False,False],inplace=True)
                portfolio_others = portfolio_others.reset_index(drop=True)
            if len(portfolio_hold)>0:
                for i, ind in enumerate(portfolio_others.indicator):
                    for i_h in range(n_1, len(portfolio_hold)):
                        if (portfolio_hold.loc[i_h,'t']<2) and (portfolio_others.loc[i,'t']<2):
                            if (ind-portfolio_hold.loc[i_h,'indicator']>para[2] or portfolio_hold.loc[i_h,'signal']<=0) and portfolio_others.loc[i,'signal'] > 0:
                                for i_j in range(len(portfolio_hold)-1,i_h, -1):
                                    portfolio_hold.loc[i_j,:]=portfolio_hold.loc[i_j-1,:]                           
                                portfolio_hold.loc[i_h,:]=portfolio_others.loc[i,:]
                                n_1 = i_h + 1
                                break
                    if i_h == len(portfolio_hold) - 1:
                        break
        
            hold_num = len(portfolio_hold)
            portfolio_1 = portfolio_hold.loc[portfolio_hold['signal']>0,]
   
            # 當日市價、合併分割與股利資料
            px_prev = pd.DataFrame(holdings['px_m'])
            holdings[cor_act_col_name] = 0
            holdings[['o_t','px_m','vol','Adj_Factor_rev','DVD','t']] = signal_t[['stk_bbg','PX_OPEN','PX_LAST','PX_VOLUME','Adj_Factor_rev','DVD','t']].set_index('stk_bbg')
            holdings['DVD'].fillna(0,inplace=True)
            holdings['Adj_Factor_rev'].fillna(1,inplace=True)
            holdings['t'].fillna(2,inplace=True)
            # 處裡分割(股數與庫存成本)
            holdings['shares'] = holdings['shares']* holdings['Adj_Factor_rev']
            holdings['px'] = holdings['cost']/ holdings['shares']
            # 處理股利(前一天市值乘上股利率)
            holdings['dvd'] = holdings['dvd'] + holdings['mv'] * holdings['DVD']*(1-performance_set[4])
            # # 合併最新權重
            holdings['p_w_1'] = holdings['p_w']
            holdings['p_w'] = 0
            holdings.loc[portfolio_1['stk_bbg'],'p_w'] = 1/para[0]
            holdings['p_w_1'] = holdings['p_w']-holdings['p_w_1']
            if abs(holdings['p_w_1']).sum()>0:
                # 買進
                holdings['t_shares'] = round(holdings['p_w_1']*performance_set[0]/px_prev['px_m']/performance_set[5],0)*performance_set[5]
                # # 實際交易情況
                holdings['p_t']=(holdings['o_t'] + holdings['px_m'])/2
                holdings['t_shares'].fillna(0,inplace=True)
                # 若當天有分割，要處裡股數
                holdings['t_shares'] = holdings['t_shares'] * holdings['Adj_Factor_rev']          
                # 全數賣出(賣出不用處裡分割股數)
                holdings.loc[holdings['p_w_1']<0,'t_shares'] = -holdings['shares']
                # 交易金額
                holdings['t_amt']=holdings['t_shares'] * holdings['p_t']
                holdings.loc[holdings['t_shares'] > 0 , 't_amt'] = holdings['t_amt']*(1+performance_set[1]+performance_set[2])
                holdings.loc[holdings['t_shares'] < 0 , 't_amt'] = holdings['t_amt']*(1-performance_set[1]-performance_set[2]-performance_set[3])
                df_trade = holdings.loc[holdings['t_shares']!=0,['t_shares','t_amt']]
                df_trade['date'] = date
                df_trade.reset_index(inplace=True)
                df_trade.set_index('date',inplace=True, drop=True)                     
                # # 滾入庫存
                # # 庫存股數
                holdings['shares'] = holdings['shares'] + holdings['t_shares']
                # # 庫存成本
                # # 如果是買單，直接加入庫存成本
                holdings.loc[holdings['t_shares'] > 0 , 'cost'] = holdings['cost'] + holdings['t_amt']  
                # # # 如果是賣單，用均價從庫存成本扣除   僅適用於非全數賣出，全數賣出則出清
                holdings.loc[holdings['t_shares'] < 0 , 'cost'] = holdings['cost'] + holdings['t_shares']*holdings['px']
                # # 如果全數賣出，庫存成本歸零
                holdings.loc[holdings['shares']==0,'cost'] = 0
                # # 如果是賣單，計算已實現損益
                holdings.loc[holdings['t_shares'] < 0 , 'real_pl'] = holdings['real_pl'] + (-holdings['t_amt']+holdings['t_shares']*holdings['px'])
                # # 重算庫存成本
                holdings['px'] = holdings['cost'] / holdings['shares']
            # # 如果沒有市價，可能是停牌，因此補前日資料
            holdings.loc[holdings['px_m'].isnull(),'px_m'] = px_prev['px_m']    
            # 重算市值
            holdings['mv'] = holdings['px_m'] * holdings['shares']
            # 重算未實現損益
            holdings['unreal_pl'] = holdings['mv'] - holdings['cost']
            # # 重算報酬率
            holdings['ret'] = holdings['unreal_pl']/holdings['cost'] 
            # # 重算總損益
            holdings.fillna(0,inplace=True)
            holdings['tlt_pl'] = holdings['unreal_pl'] + holdings['real_pl'] + holdings['dvd'] 
            # 績效表現彙總
            for i in (perf_col_name):
                performance.loc[date, i] = holdings[i].sum()
        # 計算報酬率
        performance['p_ret'] = (performance['tlt_pl']-performance['tlt_pl'].shift(1))/(abs(performance['mv'].shift(1)))
        performance[['b_ret','b_O','b_L']] = df_index.loc[df_index['date'].isin(trade_dates_start.date),['date','PX_Return','PX_OPEN','PX_LAST']].set_index(['date'])
        performance.loc[performance['cost'].shift(1)==0,['p_ret','b_ret']] = 0
        performance.loc[performance.index<=performance['cost'].ne(0).idxmax(),['p_ret','b_ret']] = 0
        performance.loc[(performance['cost'].shift(periods=2,fill_value=0)==0) & (performance['cost'].shift(1)>0),'p_ret'] = (performance['tlt_pl']-performance['tlt_pl'].shift(periods=2,fill_value=0))/(performance['mv'].shift(1))
        performance.loc[(performance['cost'].shift(periods=2,fill_value=0)==0) & (performance['cost'].shift(1)>0),'b_ret'] = (performance['b_L']-((performance['b_O'].shift(1)+performance['b_L'].shift(1))/2))/((performance['b_O'].shift(1)+performance['b_L'].shift(1))/2)   
        performance['p_ret_cul'] = ((performance['p_ret']+1).cumprod())
        performance['b_ret_cul'] = ((performance['b_ret']+1).cumprod())
        performance = performance.loc[:,perf_col_name + ret_col_name]
        performance_year=performance.loc[performance.groupby(performance.index.year).tail(1).index,['p_ret_cul','b_ret_cul']]
        performance_year['p_ret'] = (performance_year['p_ret_cul']/performance_year['p_ret_cul'].shift(1))-1
        performance_year['b_ret'] = (performance_year['b_ret_cul']/performance_year['b_ret_cul'].shift(1))-1
        performance_year.loc[performance_year.index[0],'p_ret']=performance_year.loc[performance_year.index[0],'p_ret_cul']-1
        performance_year.loc[performance_year.index[0],'b_ret']=performance_year.loc[performance_year.index[0],'b_ret_cul']-1
        performance_year['alpha']=performance_year['p_ret']-performance_year['b_ret']
        
        return performance_year
    
    def strategy_slpoe(self,strategy_rank_data,df_index,trade_dates_start,*para):
        para = para[0]
        slpo_y = strategy_rank_data.pivot(index='date', columns='stk_bbg', values='adj_PX_LAST')
        slpo_y = pd.merge(df_index.date,slpo_y, on=['date'],how='left')
        # 如果有缺資料，補前值計算斜率會有問題
        slpo_y.fillna(method='ffill',inplace=True)
        slpo_y.set_index('date',drop=True,inplace=True)
        slpo_x = pd.Series(np.arange(len(slpo_y.index)), slpo_y.index, name='number')
        slopes = rolling_calc_slope(slpo_y, slpo_x, para[3])
        slopes = pd.melt(slopes.reset_index(), id_vars='date',value_name='indicator')
        # strategy_rank_data  = pd.merge(strategy_rank_data,slopes, on=['date','stk_bbg'],how='left')
        strategy_rank_data  = pd.merge(strategy_rank_data,slopes, left_on=['date','stk_bbg'],right_on=['date','variable'],how='left')
        # 斜率大於0訊號是1，否則0
        strategy_rank_data['signal'] = strategy_rank_data['indicator'].apply(lambda x: 1 if x >= 0 else -1)
        # 如果被併購，最後一天訊號為-1
        strategy_rank_data.loc[strategy_rank_data['t']==0,'signal']=-1
        # 不是成份股的標的不列入計算
        strategy_rank_data.loc[pd.isnull(strategy_rank_data['weight_']), 'signal'] = 0
        # 如果當日停牌，則無法買賣
        strategy_rank_data.loc[strategy_rank_data['t']==2,'signal']=2
        # 排序
        strategy_rank_data.sort_values(by=['date','signal','indicator'],ascending=[True,False,False],inplace=True)
        # # Rank
        strategy_rank_data['rank'] = strategy_rank_data.groupby(['date']).cumcount()+1
        # # 選股
        # top_portfolio = strategy_rank_data.groupby('date')['date','stk_bbg','signal','indicator'].head(para[0])
        # top_portfolio = top_portfolio.loc[(top_portfolio['signal']>0) & (top_portfolio['date']>=start_trade_date_d)]
        # top_portfolio.set_index('date',drop=True,inplace=True)
        # 換股
        portfolio_1=pd.DataFrame(columns=['stk_bbg','signal','indicator'])
        top_portfolio=[]
        for d, date in enumerate(trade_dates_start.date):
            n_1=0
            portfolio = strategy_rank_data.loc[strategy_rank_data['date']==date,['stk_bbg','signal','indicator']]  
            portfolio_hold = portfolio.loc[portfolio['stk_bbg'].isin(portfolio_1['stk_bbg']),]
            portfolio_hold.sort_values(['signal','indicator'],inplace=True)
            portfolio_hold.reset_index(drop=True,inplace=True)
            portfolio_others = portfolio.loc[~portfolio['stk_bbg'].isin(portfolio_1['stk_bbg']),]
            portfolio_others.reset_index(drop=True,inplace=True)
            for i, ind in enumerate(portfolio_others.indicator):
                if not portfolio_1.empty:
                    for i_h in range(n_1, para[0]):
                        if (ind-portfolio_hold.loc[i_h,'indicator']>para[2] or portfolio_hold.loc[i_h,'signal']<=0) and portfolio_others.loc[i,'signal'] > 0:
                            portfolio_hold.loc[i_h,:]=portfolio_others.loc[i,:]
                            n_1 = i_h + 1
                            break
                else:
                    portfolio_hold=portfolio_others.iloc[0:para[0],]
            portfolio_1 = portfolio_hold.loc[portfolio_hold['signal']>0,]
            if not portfolio_1.empty:
                portfolio_1['date']=date
                top_portfolio.append(portfolio_1)    
        top_portfolio = pd.concat(top_portfolio, axis=0)    
        top_portfolio['weight']=1/para[0]
        return strategy_rank_data,top_portfolio
    
    def strategy_slope_indicator(self,strategy_rank_data,df_index,trade_dates_start,para):
        slpo_y = strategy_rank_data.pivot(index='date', columns='stk_bbg', values='adj_PX_LAST')
        slpo_y = pd.merge(df_index.date,slpo_y, on=['date'],how='left')
        # 如果有缺資料，補前值計算斜率會有問題
        slpo_y.fillna(method='ffill',inplace=True)
        slpo_y.set_index('date',drop=True,inplace=True)
        slpo_x = pd.Series(np.arange(len(slpo_y.index)), slpo_y.index, name='number')
        slopes = self.rolling_calc_slope(slpo_y, slpo_x, para)
        slopes = pd.melt(slopes.reset_index(), id_vars='date',value_name='indicator')
        # strategy_rank_data  = pd.merge(strategy_rank_data,slopes, on=['date','stk_bbg'],how='left')
        strategy_rank_data  = pd.merge(strategy_rank_data,slopes, left_on=['date','stk_bbg'],right_on=['date','variable'],how='left')
        # 斜率大於0訊號是1，否則0
        strategy_rank_data['signal'] = strategy_rank_data['indicator'].apply(lambda x: 1 if x >= 0 else -1)
        # 如果被併購，最後一天訊號為0
        strategy_rank_data.loc[strategy_rank_data['t']==0,'signal'] = 0
        # 不是成份股的標的不列入計算
        strategy_rank_data.loc[pd.isnull(strategy_rank_data['weight_']), 'signal'] = 0
        # 排序
        strategy_rank_data.sort_values(by=['date','signal','indicator'],ascending=[True,False,False],inplace=True)
        # # # Rank
        # strategy_rank_data['rank'] = strategy_rank_data.groupby(['date']).cumcount()+1
        return strategy_rank_data[['date','stk_bbg','signal','indicator']]

    def strategy_slope_indicator_sox(self,strategy_rank_data,df_index,trade_dates_start,para):
        slpo_y = strategy_rank_data.pivot(index='date', columns='stk_bbg', values='adj_PX_LAST')
        slpo_y = pd.merge(df_index.date,slpo_y, on=['date'],how='left')
        # 如果有缺資料，補前值計算斜率會有問題
        slpo_y.fillna(method='ffill',inplace=True)
        slpo_y.set_index('date',drop=True,inplace=True)
        slpo_x = pd.Series(np.arange(len(slpo_y.index)), slpo_y.index, name='number')
        slopes = self.rolling_calc_slope(slpo_y, slpo_x, para)
        slopes = pd.melt(slopes.reset_index(), id_vars='date',value_name='indicator')
        # strategy_rank_data  = pd.merge(strategy_rank_data,slopes, on=['date','stk_bbg'],how='left')
        strategy_rank_data  = pd.merge(strategy_rank_data,slopes, left_on=['date','stk_bbg'],right_on=['date','variable'],how='left')
        # 斜率大於0訊號是1，否則0
        strategy_rank_data['signal'] = strategy_rank_data['indicator'].apply(lambda x: 1 if x >= 0.001 else -1)
        # 如果被併購，最後一天訊號為0
        strategy_rank_data.loc[strategy_rank_data['t']==0,'signal']=0
        # 不是成份股的標的不列入計算
        strategy_rank_data.loc[pd.isnull(strategy_rank_data['weight_']), 'signal'] = 0
        # 排序
        strategy_rank_data.sort_values(by=['date','signal','indicator'],ascending=[True,False,False],inplace=True)
        # # # Rank
        # strategy_rank_data['rank'] = strategy_rank_data.groupby(['date']).cumcount()+1
        return strategy_rank_data[['date','stk_bbg','signal','indicator']]
        
    def calc_beta(self,s: np.ndarray, m: np.ndarray):
        x = np.vstack((np.ones_like(m), m))
        b = np.linalg.pinv(x.dot(x.T)).dot(x).dot(s)
        return b[1]
    
    def rolling_calc_beta(self,s_df, m_df, period):
        result = np.ndarray(shape=s_df.shape, dtype=float)
        l, w = s_df.shape
        ls, ws = s_df.values.strides
        result[0:period, :] = np.nan
        s_arr = np.lib.stride_tricks.as_strided(s_df.values, shape=(l - period + 1, period, w), strides=(ls, ls, ws))
        m_arr= self.rwindows(m_df.values, period)
    #    m_arr = as_strided(m_df.values, shape=(l - period + 1, period), strides=(ls, ls))
        for row in range(period, l):
            result[row, :] = calc_beta(s_arr[row - period, :], m_arr[row - period])
        return pd.DataFrame(data=result, index=s_df.index, columns=s_df.columns)
    
    def calc_slpoe(self,s: np.ndarray, m: np.ndarray):
        s = s.astype(np.float64)
        m = m.astype(np.float64)
        x = np.vstack((np.ones_like(m), m))
        b = np.linalg.pinv(x.dot(x.T)).dot(x).dot(s)
    #  return b[1]
        return b[1]/s[0,:]
    
    def rolling_calc_slope(self,s_df, m_df, period):
        result = np.ndarray(shape=s_df.shape, dtype=float)
        l, w = s_df.shape
        ls, ws = s_df.values.strides
        result[0:period, :] = np.nan
        # 從0開始抓para[1](0~para[1]-1)個資料，並記錄在para[1]
        s_arr = np.lib.stride_tricks.as_strided(s_df.values, shape=(l - period + 1, period, w), strides=(ls, ls, ws))
        m_arr= self.rwindows(m_df.values, period)
    #    m_arr = as_strided(m_df.values, shape=(l - period + 1, period), strides=(ls, ls))
        # # l為抓到今日以前的收盤，放在明日的訊號
        # row開始，會計算0:row-1的資料(row - para[1] = 0)
        # for row in range(period-1, l):
        #     result[row, :] = self.calc_slpoe(s_arr[row - period+1, :], m_arr[row - period+1])
        for row in range(period, l):
            result[row, :] = self.calc_slpoe(s_arr[row - period, :], m_arr[row - period])   
    # =============================================================================
    #     # test
    #     slpo_y = strategy_rank_data.pivot(index='date', columns='stk_bbg', values='adj_PX_LAST')
    #     slpo_y = pd.merge(df_index.date,slpo_y, on=['date'],how='left')
    #     slpo_y.fillna(method='ffill',inplace=True)
    #     slpo_y.set_index('date',drop=True,inplace=True)
    #     slpo_x = pd.Series(np.arange(len(slpo_y.index)), slpo_y.index, name='number')
    #     # slopes = my_func.rolling_calc_slope(slpo_y, slpo_x, para[1])
    #     
    #     result = np.ndarray(shape=slpo_y.shape, dtype=float)
    #     l, w = slpo_y.shape
    #     ls, ws = slpo_y.values.strides
    #     result[0:para[1], :] = np.nan
    #     # 從0開始抓para[1](0~para[1]-1)個資料，並記錄在para[1]
    #     s_arr = np.lib.stride_tricks.as_strided(slpo_y.values, shape=(l - para[1] + 1, para[1], w), strides=(ls, ls, ws))
    #     # m_arr= my_func.rwindows(slpo_x.values, para[1])
    #     # # l為抓到今日以前的收盤，放在明日的訊號
    #     # row開始，會計算0:row-1的資料(row - para[1] = 0)
    #     for row in range(para[1], l):
    #         result[row, :] = my_func.calc_slpoe(s_arr[row - para[1], :], m_arr[row - para[1]])
    # =============================================================================    
        return pd.DataFrame(data=result, index=s_df.index, columns=s_df.columns)
    
    def calc_zscore(self,s: np.ndarray):
        b=zscore(s)
        return b[-1]
    
    def rolling_calc_zscore(self,s_df, period):
        result = np.ndarray(shape=s_df.shape, dtype=float)
        l, w = s_df.shape
        ls, ws = s_df.values.strides
        result[0:period, :] = np.nan
        # 從0開始抓para[1](0~para[1]-1)個資料，並記錄在para[1]
        s_arr = np.lib.stride_tricks.as_strided(s_df.values, shape=(l - period + 1, period, w), strides=(ls, ls, ws))
        # # l為抓到今日以前的收盤，放在明日的訊號
        # row開始，會計算0:row-1的資料(row - para[1] = 0)
        # for row in range(period-1, l):
        #     result[row, :] = self.calc_zscore(s_arr[row - period+1, :])
        for row in range(period, l):
            result[row, :] = self.calc_zscore(s_arr[row - period, :])   
   
        return pd.DataFrame(data=result, index=s_df.index, columns=s_df.columns)
    
    def strategy_zscore_indicator(self,strategy_rank_data,df_index,trade_dates_start,para):
        px_last = strategy_rank_data.pivot(index='date', columns='stk_bbg', values='adj_PX_LAST')
        px_last = pd.merge(df_index.date,px_last, on=['date'],how='left')
        # 如果有缺資料，補前值計算斜率會有問題
        px_last.fillna(method='ffill',inplace=True)
        px_last.set_index('date',drop=True,inplace=True)
        zscore = self.rolling_calc_zscore(px_last, para)
        zscore = pd.melt(zscore.reset_index(), id_vars='date',value_name='indicator')
        strategy_rank_data  = pd.merge(strategy_rank_data,zscore, left_on=['date','stk_bbg'],right_on=['date','variable'],how='left')
        # zscore大於0訊號是4，否則0
        # strategy_rank_data['signal'] = strategy_rank_data['indicator'].apply(lambda x: 1 if x >=-4 else -1)
        # strategy_rank_data['signal'] = strategy_rank_data['indicator'].apply(lambda x: 1 if x >=0 else -1)
        strategy_rank_data['signal'] = strategy_rank_data['indicator'].apply(lambda x: 1 if x >=-1 else -1)
        # 如果被併購，最後一天訊號為0
        strategy_rank_data.loc[strategy_rank_data['t']==0,'signal']=0
        # 不是成份股的標的不列入計算
        strategy_rank_data.loc[pd.isnull(strategy_rank_data['weight_']), 'signal'] = 0
        # 排序
        strategy_rank_data.sort_values(by=['date','signal','indicator'],ascending=[True,False,False],inplace=True)
        return strategy_rank_data[['date','stk_bbg','signal','indicator']]

    def strategy_zscore_indicator_sox(self,strategy_rank_data,df_index,trade_dates_start,para):
        px_last = strategy_rank_data.pivot(index='date', columns='stk_bbg', values='adj_PX_LAST')
        px_last = pd.merge(df_index.date,px_last, on=['date'],how='left')
        # 如果有缺資料，補前值計算斜率會有問題
        px_last.fillna(method='ffill',inplace=True)
        px_last.set_index('date',drop=True,inplace=True)
        zscore = self.rolling_calc_zscore(px_last, para)
        zscore = pd.melt(zscore.reset_index(), id_vars='date',value_name='indicator')
        strategy_rank_data  = pd.merge(strategy_rank_data,zscore, left_on=['date','stk_bbg'],right_on=['date','variable'],how='left')
        # zscore大於0訊號是4，否則0
        # strategy_rank_data['signal'] = strategy_rank_data['indicator'].apply(lambda x: 1 if x >=-4 else -1)
        # strategy_rank_data['signal'] = strategy_rank_data['indicator'].apply(lambda x: 1 if x >=0 else -1)
        strategy_rank_data['signal'] = strategy_rank_data['indicator'].apply(lambda x: 1 if x >=-1 else -1)
        # 如果被併購，最後一天訊號為0
        strategy_rank_data.loc[strategy_rank_data['t']==0,'signal']=0
        # 不是成份股的標的不列入計算
        strategy_rank_data.loc[pd.isnull(strategy_rank_data['weight_']), 'signal'] = 0
        # 排序
        strategy_rank_data.sort_values(by=['date','signal','indicator'],ascending=[True,False,False],inplace=True)
        return strategy_rank_data[['date','stk_bbg','signal','indicator']]
    
    # def calc_statistic_high(self,s: np.ndarray):
    #     b=np.ndarray.max(s)
    #     return b[-1]

    # def calc_statistic_low(self,s: np.ndarray):
    #     b=np.ndarray.min(s)
    #     return b[-1]
    
    def rolling_calc_statistic_v(self,s_df, period):
        result = np.ndarray(shape=s_df.shape, dtype=float)
        df_max = np.ndarray(shape=s_df.shape, dtype=float)
        df_min = np.ndarray(shape=s_df.shape, dtype=float)
        l, w = s_df.shape
        ls, ws = s_df.values.strides
        result[0:period, :] = np.nan
        df_max[0:period, :] = np.nan
        df_min[0:period, :] = np.nan
        # 從0開始抓para[1](0~para[1]-1)個資料，並記錄在para[1]
        s_arr = np.lib.stride_tricks.as_strided(s_df.values, shape=(l - period + 1, period, w), strides=(ls, ls, ws))
        # # l為抓到今日以前的收盤，放在明日的訊號
        # row開始，會計算0:row-1的資料(row - para[1] = 0)
        # for row in range(period-1, l):            
        #     df_max[row, :] = np.max(s_arr[row - period+1, :],axis=0)
        #     df_min[row, :] = np.min(s_arr[row - period+1, :],axis=0)
        for row in range(period, l):            
            df_max[row, :] = np.max(s_arr[row - period, :],axis=0)
            df_min[row, :] = np.min(s_arr[row - period, :],axis=0)
        result = (df_max - df_min)/df_min
        return pd.DataFrame(data=result, index=s_df.index, columns=s_df.columns)
    
    def rolling_calc_statistic_p(self,s_df, period):
        result = np.ndarray(shape=s_df.shape, dtype=float)
        l, w = s_df.shape
        ls, ws = s_df.values.strides
        result[0:period, :] = np.nan
        # 從0開始抓para[1](0~para[1]-1)個資料，並記錄在para[1]
        s_arr = np.lib.stride_tricks.as_strided(s_df.values, shape=(l - period + 1, period, w), strides=(ls, ls, ws))
        # df_pct = px_last.rolling(window=period).apply(pctrank)
        # pctrank = lambda x: pd.Series(x).rank(pct=True).iloc[-1]
        
        # def pctrank(x):
        #     n = len(x)
        #     temp = x.argsort()
        #     ranks = np.empty(n)
        #     ranks[temp] = (np.arange(n) + 1) / n
        #     return ranks[-1]
        
        # # l為抓到今日以前的收盤，放在明日的訊號
        # row開始，會計算0:row-1的資料(row - para[1] = 0)
        # for row in range(period-1, l):            
        #     result[row, :] = ((s_arr[row - period+1, :].argsort(axis=0).argsort(axis=0) + 1)/period)[-1]
        for row in range(period, l):            
            result[row, :] = ((s_arr[row - period, :].argsort(axis=0).argsort(axis=0) + 1)/period)[-1]
        return pd.DataFrame(data=result, index=s_df.index, columns=s_df.columns)
    
    def rolling_calc_statistic_s(self,s_df, period):
        result = np.ndarray(shape=s_df.shape, dtype=float)
        l, w = s_df.shape
        ls, ws = s_df.values.strides
        result[0:period, :] = np.nan
        # 從0開始抓para[1](0~para[1]-1)個資料，並記錄在para[1]
        s_arr = np.lib.stride_tricks.as_strided(s_df.values, shape=(l - period + 1, period, w), strides=(ls, ls, ws))
        # # l為抓到今日以前的收盤，放在明日的訊號
        # row開始，會計算0:row-1的資料(row - para[1] = 0)
        # for row in range(period-1, l):
        #     result[row, :] = skew(s_arr[row - period+1, :],axis=0,bias=True)/3
        for row in range(period, l):
            result[row, :] = skew(s_arr[row - period, :],axis=0,bias=True)/3
        return pd.DataFrame(data=result, index=s_df.index, columns=s_df.columns)
    
    def rolling_calc_statistic_k(self,s_df, period):
        result = np.ndarray(shape=s_df.shape, dtype=float)
        l, w = s_df.shape
        ls, ws = s_df.values.strides
        result[0:period, :] = np.nan
        # 從0開始抓para[1](0~para[1]-1)個資料，並記錄在para[1]
        s_arr = np.lib.stride_tricks.as_strided(s_df.values, shape=(l - period + 1, period, w), strides=(ls, ls, ws))
        # # l為抓到今日以前的收盤，放在明日的訊號
        # row開始，會計算0:row-1的資料(row - para[1] = 0)
        # for row in range(period-1, l):            
        #     result[row, :] = kurtosis(s_arr[row - period+1, :],axis=0,fisher=True,bias=False)/3
        for row in range(period, l):            
            result[row, :] = kurtosis(s_arr[row - period, :],axis=0,fisher=True,bias=False)/3
        return pd.DataFrame(data=result, index=s_df.index, columns=s_df.columns)
    
    def strategy_statistic_indicator(self,strategy_rank_data,df_index,trade_dates_start,para):
        px_last = strategy_rank_data.pivot(index='date', columns='stk_bbg', values='adj_PX_LAST')
        px_last = pd.merge(df_index.date,px_last, on=['date'],how='left')
        # 如果有缺資料，補前值計算斜率會有問題
        px_last.fillna(method='ffill',inplace=True)
        px_last.set_index('date',drop=True,inplace=True)
        V = self.rolling_calc_statistic_v(px_last, para)
        V = pd.melt(V.reset_index(), id_vars='date',value_name='indicator')
        P = self.rolling_calc_statistic_p(px_last, para)
        P = pd.melt(P.reset_index(), id_vars='date',value_name='indicator')    
        S = self.rolling_calc_statistic_s(px_last, para)
        S = pd.melt(S.reset_index(), id_vars='date',value_name='indicator') 
        K = self.rolling_calc_statistic_k(px_last, para)
        K = pd.melt(K.reset_index(), id_vars='date',value_name='indicator')         
        # statistic = V+P-S+K
        # statistic = V.set_index(['date','variable'])+P.set_index(['date','variable'])-S.set_index(['date','variable'])+K.set_index(['date','variable'])
        statistic = P.set_index(['date','variable'])-S.set_index(['date','variable'])+K.set_index(['date','variable'])
        strategy_rank_data  = pd.merge(strategy_rank_data,statistic, left_on=['date','stk_bbg'],right_on=['date','variable'],how='left')
        # 訊號都是1
        strategy_rank_data['signal'] = 1
        # 如果被併購，最後一天訊號為0
        strategy_rank_data.loc[strategy_rank_data['t']==0,'signal']=0
        # 不是成份股的標的不列入計算
        strategy_rank_data.loc[pd.isnull(strategy_rank_data['weight_']), 'signal'] = 0
        # 排序
        strategy_rank_data.sort_values(by=['date','signal','indicator'],ascending=[True,False,False],inplace=True)
        return strategy_rank_data[['date','stk_bbg','signal','indicator']]
   
    def winsorize_arrays(self,strategy_rank_data,df_index,trade_dates_start,para):
        px_return = strategy_rank_data.pivot(index='date', columns='stk_bbg', values='PX_Return')
        px_return = pd.merge(df_index.date,px_return, on=['date'],how='left')
        px_return.fillna(0,inplace=True)
        px_return.set_index('date',drop=True,inplace=True) 
        result = np.ndarray(shape=px_return.shape, dtype=float)
        l, w = px_return.shape
        ls, ws = px_return.values.strides
        result[0:para, :] = np.nan
        # 從0開始抓para[1](0~para[1]-1)個資料，並記錄在para[1]
        s_arr = np.lib.stride_tricks.as_strided(px_return.values, shape=(l - para + 1, para, w), strides=(ls, ls, ws))
        # # l為抓到今日以前的收盤，放在明日的訊號
        # row開始，會計算0:row-1的資料(row - para[1] = 0)
        for row in range(para, l):
            result[row, :] = mstats.winsorize(s_arr[row - para + 1, :],axis=0,limits=[0.1, 0.1])[-1]
        W = pd.DataFrame(data=result, index=px_return.index, columns=px_return.columns)
        W = pd.melt(W.reset_index(), id_vars='date',value_name='indicator')
        W.rename(columns={'variable':'stk_bbg','indicator':'PX_Return'},inplace=True)   
        return W
    
    def reindex_by_date(self,df,dates):
         df.set_index('date', inplace=True,drop=True)
         df_new = df.reindex(dates)
         return df_new
     
    def expand_dates(self,df,end_date):
        df.set_index('date', inplace=True,drop=True)
        start = df.index.min()
        end = end_date
        dates = pd.date_range(start, end, freq='D').rename('date')
        df_new = df.reindex(dates)
        return df_new
        
        
    def cal_trade_profile(self,trade, hold_portfolio, plot_distribution=False, init_amt=1e8):

        trade = trade.reset_index()

        # 建立交易紀錄表
        trade_records = []

        # 建立一個字典來追蹤每支股票的進場資訊
        entry_dict = {}

        # 依照日期排序並逐日處理
        for date in sorted(hold_portfolio['date'].unique()):
            today_holdings = hold_portfolio[hold_portfolio['date'] == date]['stk_bbg'].tolist()
            prev_holdings = list(entry_dict.keys())

            # 找出新進場的股票
            new_entries = set(today_holdings) - set(prev_holdings)
            for stk in new_entries:
                entry = trade[(trade['date'] == date) & (trade['stk_bbg'] == stk)]
                entry_amt = entry['t_amt'].values[0] if not entry.empty else np.nan
                entry_dict[stk] = {'entry_date': date, 'entry_amt': entry_amt}

            # 找出已出場的股票
            exits = set(prev_holdings) - set(today_holdings)
            for stk in exits:
                entry_info = entry_dict.pop(stk)
                exit = trade[(trade['date'] == date) & (trade['stk_bbg'] == stk)]
                exit_amt = abs(exit['t_amt'].values[0]) if not exit.empty else np.nan
                profit = exit_amt - entry_info['entry_amt'] if pd.notna(exit_amt) and pd.notna(entry_info['entry_amt']) else np.nan
                is_win = profit > 0 if pd.notna(profit) else np.nan

                trade_records.append({
                    'stk_bbg': stk,
                    'entry_date': entry_info['entry_date'],
                    'exit_date': date,
                    'hold_days': int((date - entry_info['entry_date']) / np.timedelta64(1, 'D')),
                    'entry_amt': entry_info['entry_amt'],
                    'exit_amt': exit_amt,
                    'profit': profit,
                    'profit%' : profit / entry_info['entry_amt'],
                    'is_win': is_win
                })

        # 建立交易紀錄 DataFrame
        trade_log = pd.DataFrame(trade_records)

        # 勝率（Win Rate）：勝場數 / 總交易數（包含 NaN）
        total_trades = len(trade_log)
        win_trades = (trade_log['is_win'] == True).sum(skipna=True)
        loss_trades = (trade_log['is_win'] == False).sum(skipna=True)
        win_rate = win_trades / total_trades if total_trades > 0 else np.nan

        # 過濾出賺錢與虧損交易
        winning_trades = trade_log[trade_log['profit'] > 0]['profit']
        losing_trades = trade_log[trade_log['profit'] < 0]['profit']

        winning_trades_pct = trade_log[trade_log['profit%'] > 0]['profit%']
        losing_trades_pct = trade_log[trade_log['profit%'] < 0]['profit%']    

        # 計算平均獲利與平均虧損（取絕對值）
        sum_gain = winning_trades.sum()
        sum_loss = losing_trades.abs().sum()

        avg_gain = winning_trades.mean()
        avg_loss = losing_trades.abs().mean()

        avg_gain_pct = winning_trades_pct.mean()
        max_gain_pct = winning_trades_pct.max()
        min_gain_pct = winning_trades_pct.min()

        avg_loss_pct = losing_trades_pct.mean()    
        max_loss_pct = losing_trades_pct.min()
        min_loss_pct = losing_trades_pct.max()

        # 計算
        slugging_ratio = avg_gain / avg_loss if avg_loss != 0 else np.nan
        PF_Factor = sum_gain / sum_loss if sum_loss != 0 else np.nan

        kelly = (slugging_ratio * win_rate - (1-win_rate)) / slugging_ratio
        # expectations = win_rate * avg_gain - (1-win_rate) * avg_loss
        expectations = win_rate * slugging_ratio

        avg_hold_days = trade_log["hold_days"].mean()
        max_hold_days = trade_log["hold_days"].max()
        min_hold_days = trade_log["hold_days"].min()

        trade_profile = {
            "總交易次數" : total_trades,

            "初始投資金額" : init_amt,

            "勝率%" : round(win_rate,2),
            "平均持倉天數" : round(avg_hold_days,0),
            "最大持倉天數" : max_hold_days,
            "最小持倉天數" : min_hold_days,
            "每筆交易賺賠比" : round(slugging_ratio,2),
            "總獲利/總虧損" : round(PF_Factor,2),
            "策略期望值(R)" : round(expectations,2),
            "Kelly值" : round(kelly,2),
            
            "獲利次數" : win_trades,
            "總獲利金額" : round(sum_gain,0),
            "平均獲利金額" : round(avg_gain,0),
            "平均獲利%" : round(avg_gain_pct,2),
            "最大獲利%" : round(max_gain_pct,2),
            "最小獲利%" : round(min_gain_pct,2),

            "虧損次數" : loss_trades,
            "總虧損金額" : round(sum_loss,0),        
            "平均虧損金額" : round(avg_loss,0),
            "平均虧損%" : round(avg_loss_pct,2),
            "最大虧損%" : round(max_loss_pct,2),
            "最小虧損%" : round(min_loss_pct,2),

        }

        if plot_distribution:
            plt.figure(figsize=(10, 6))
            plt.hist(trade_log['profit%'].dropna(), bins=30, edgecolor='black')
            plt.title('Distribution of Trade Profits%')
            plt.xlabel('Profit')
            plt.ylabel('Number of Trades')
            plt.grid(False)
            plt.tight_layout()
            plt.show()

        trade_profile = pd.DataFrame([trade_profile]).T

        # 顯示結果
        return trade_log, trade_profile     
        
        
    