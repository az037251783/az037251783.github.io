# slope_demo_simulate.py
# -*- coding: utf-8 -*-
"""
Slope 策略回測報表  合成資料測試腳本
--------------------------------------
模擬從 SQL 讀取資料後的完整回測流程，用以驗證 slope_demo_report.py 輸出。

設計要點:
  - GBM + 共同市場因子 + 動量(rho=0.10) -> slope 具預測力
  - 加入 COVID 崩盤(-34%)、V型反彈、2022 熊市(-25%) 三大事件
  - 大盤累積報酬率保持正值，貼近真實 SPX 2020-2023 走勢
"""

import warnings; warnings.filterwarnings('ignore')
import numpy as np
import pandas as pd
import time

from slope_demo_report import build_report, build_backtest_report

print("=" * 60)
print("Slope Strategy Backtest Report  Demo Simulation")
print("=" * 60)

# ===============================================================
# §1  參數
# ===============================================================

SEED         = 2024
np.random.seed(SEED)

START_DATA   = '20190101'
START_TRADE  = '20200101'
END_DATE     = '20230630'
INI_AMT      = 1_000_000
STK_NUM      = 5
STOP_LOSS    = -0.25
SLOPE_PERIOD = 120
CRT_CHG      = 0.0058
INDEX_NAME   = 'SPX Index'
SLIP         = 0.001
COMM         = 0.001
TAX_S        = 0.001

OPT_PERIODS  = [90, 120, 150]
OPT_CRTS     = [round(v, 4) for v in np.arange(0.005, 0.00602, 0.0002)]

UNIVERSE = [
    'AAPL US Equity', 'MSFT US Equity', 'NVDA US Equity', 'GOOGL US Equity',
    'META US Equity', 'AMZN US Equity', 'TSLA US Equity', 'JPM US Equity',
    'V US Equity',    'UNH US Equity',  'XOM US Equity',  'JNJ US Equity',
    'WMT US Equity',  'MA US Equity',   'PG US Equity',   'CVX US Equity',
    'HD US Equity',   'MRK US Equity',  'ABBV US Equity', 'LLY US Equity',
    'PEP US Equity',  'COST US Equity', 'KO US Equity',   'MCD US Equity',
    'AVGO US Equity', 'ACN US Equity',  'BAC US Equity',  'WFC US Equity',
    'DIS US Equity',  'ADBE US Equity', 'NFLX US Equity', 'CRM US Equity',
    'CMCSA US Equity','INTC US Equity', 'AMD US Equity',  'QCOM US Equity',
    'TXN US Equity',  'PFE US Equity',  'TMO US Equity',  'DHR US Equity',
    'CSCO US Equity', 'NEE US Equity',  'RTX US Equity',  'HON US Equity',
    'UPS US Equity',  'LOW US Equity',  'CAT US Equity',  'DE US Equity',
    'GS US Equity',   'MS US Equity',
]

# ===============================================================
# §2  合成市場資料
# ===============================================================

def generate_market():
    """
    GBM + 共同市場因子 + 動量 (rho=0.10)
    市場事件幅度貼近真實 SPX:
      COVID   2020-02-19 ~ 2020-03-23  -34%  (≈-1.75%/day x 24 days)
      Recovery2020-03-23 ~ 2020-08-18  +50%  (≈+0.35%/day x 123 days)
      Bear    2022-01-03 ~ 2022-10-12  -25%  (≈-0.14%/day x 196 days)
    """
    rng   = np.random.RandomState(SEED)
    dates = pd.bdate_range(START_DATA, END_DATE)
    n, m  = len(dates), len(UNIVERSE)

    # ---- SPX 日報酬 ----
    mkt = rng.normal(0.00033, 0.008, n)      # base: ~8.5% annual drift

    def _i(dt): return int(np.searchsorted(dates, pd.Timestamp(dt)))

    ci, ce = _i('2020-02-19'), _i('2020-03-23')   # COVID crash  ~24 days
    ri     = _i('2020-08-18')                       # Recovery end ~123 days
    bi, be = _i('2022-01-03'), _i('2022-10-12')   # Bear market  ~196 days

    mkt[ci:ce] = rng.normal(-0.0175, 0.018, ce - ci)   # COVID: -34% cumul
    mkt[ce:ri] = rng.normal(0.0035,  0.012, ri - ce)   # Recovery: +50% cumul
    mkt[bi:be] = rng.normal(-0.0014, 0.012, be - bi)   # 2022 bear: -25% cumul

    # Sanity check cumulative
    idx_cul = np.cumprod(1 + mkt)
    idx_level = 3700.0 * idx_cul                        # SPX start ≈ 3700 (2019)

    # ---- Individual stock returns  with momentum (rho=0.10) ----
    betas    = rng.uniform(0.75, 1.45, m)
    daily_a  = rng.normal(0.0, 0.05, m) / 252          # annual alpha -> daily
    idio_vol = rng.uniform(0.010, 0.020, m)
    rho      = 0.10                                      # autocorrelation (momentum)

    # Tech/Growth stocks (first 7) get higher beta + alpha
    betas[:7]    = rng.uniform(1.10, 1.65, 7)
    daily_a[:7] += rng.uniform(0.0003, 0.0006, 7)
    idio_vol[:7] = rng.uniform(0.018, 0.028, 7)

    stk_ret = np.zeros((n, m))
    for t in range(1, n):
        base          = daily_a + betas * mkt[t] + rng.normal(0, idio_vol, m)
        stk_ret[t]    = base + rho * stk_ret[t - 1]    # momentum carry

    px = np.empty((n, m))
    px[0] = rng.uniform(50, 500, m)
    for t in range(1, n):
        px[t] = np.maximum(px[t-1] * (1 + stk_ret[t]), 0.01)

    px_df = pd.DataFrame(px,  index=dates, columns=UNIVERSE)
    idx_df = pd.DataFrame({
        'PX_Return': mkt,
        'PX_LAST':   idx_level,
    }, index=dates)

    return px_df, idx_df, dates

# ===============================================================
# §3  Slope 指標（與 my_functions.rolling_calc_slope 一致）
# ===============================================================

def compute_slopes(px_values, period):
    """
    滾動 OLS 斜率，正規化: slope / window_first_price
    px_values: ndarray (n_days, n_stocks)
    """
    n, m = px_values.shape
    x    = np.arange(period, dtype=np.float64)
    x   -= x.mean()
    xss  = float((x ** 2).sum())

    result = np.full((n, m), np.nan)
    for i in range(period, n):
        win   = px_values[i - period:i, :]    # (period, m)
        slope = (x @ win) / xss               # (m,)
        base  = win[0, :]
        with np.errstate(divide='ignore', invalid='ignore'):
            result[i] = np.where(base != 0, slope / base, np.nan)
    return result

# ===============================================================
# §4  投資組合回測引擎
# ===============================================================

def run_backtest(px_df, idx_df, slope_arr, all_dates, trade_dates,
                 stk_num=STK_NUM, stop_loss=STOP_LOSS, crt_chg=CRT_CHG,
                 ini_amt=INI_AMT):
    """
    逐日模擬：回傳與 my_func.performance() 相同結構的六個 DataFrame。
    """
    single   = ini_amt / stk_num
    stk_list = list(px_df.columns)
    d2i      = {d: i for i, d in enumerate(all_dates)}

    shares     = {}   # {stk: float}
    cost_basis = {}   # {stk: float} 含手續費
    real_pl    = 0.0
    turnover   = 0.0
    stop_count = 0
    cooldown   = {}   # {stk: remaining_days}

    hp_rows    = []
    trade_list = []   # (date, stk, t_shares, t_amt)
    perf_rows  = []

    def _buy(date, stk, px):
        nonlocal turnover
        qty  = single / px
        cost = qty * px * (1 + SLIP + COMM)
        shares[stk]     = qty
        cost_basis[stk] = cost
        turnover += qty * px
        trade_list.append((date, stk, qty, cost))

    def _sell(date, stk, px):
        nonlocal real_pl, turnover
        qty      = shares.pop(stk)
        basis    = cost_basis.pop(stk)
        proceeds = qty * px * (1 - SLIP - COMM - TAX_S)
        real_pl += proceeds - basis
        turnover += qty * px
        trade_list.append((date, stk, -qty, -proceeds))

    for date in trade_dates:
        di = d2i.get(date)
        if di is None or di >= len(slope_arr):
            continue

        slope_s = pd.Series(slope_arr[di], index=stk_list)
        px_s    = px_df.iloc[di]

        # update cooldown
        cooldown = {s: v - 1 for s, v in cooldown.items() if v > 1}

        # stop-loss check
        for s in list(shares):
            mv  = shares[s] * px_s[s]
            ret = mv / cost_basis[s] - 1
            if ret < stop_loss:
                _sell(date, s, px_s[s])
                cooldown[s] = SLOPE_PERIOD
                stop_count += 1

        # eligible candidates (slope > 0, not in cooldown, not held)
        excluded = set(shares) | set(cooldown)
        eligible = (
            slope_s[(slope_s > 0) & ~slope_s.index.isin(excluded)]
            .sort_values(ascending=False)
        )

        # fill portfolio up to stk_num
        while len(shares) < stk_num and not eligible.empty:
            s = eligible.index[0]
            eligible = eligible.iloc[1:]
            if px_s[s] > 0:
                _buy(date, s, px_s[s])

        # swap: weakest held vs best candidate
        if shares and not eligible.empty:
            port_ind  = {s: float(slope_s.get(s, np.nan)) for s in shares}
            weakest_s = min(port_ind,
                            key=lambda s: port_ind[s] if pd.notna(port_ind[s]) else -999)
            weak_ind  = port_ind[weakest_s]
            best_s    = eligible.index[0]
            best_ind  = float(eligible.iloc[0])

            if pd.notna(best_ind) and (
                pd.isna(weak_ind) or weak_ind <= 0
                or (best_ind - weak_ind) > crt_chg
            ):
                _sell(date, weakest_s, px_s[weakest_s])
                if px_s[best_s] > 0:
                    _buy(date, best_s, px_s[best_s])

        # daily snapshot
        mv_tot   = sum(shares[s] * px_s[s] for s in shares) if shares else 0.0
        cost_tot = sum(cost_basis.values()) if cost_basis else 0.0
        b_ret    = float(idx_df.loc[date, 'PX_Return']) if date in idx_df.index else 0.0

        perf_rows.append(dict(
            date=date, mv=mv_tot, cost=cost_tot,
            unreal_pl=mv_tot - cost_tot, real_pl=real_pl,
            dvd=0.0, tlt_pl=mv_tot - cost_tot + real_pl,
            b_ret=b_ret,
        ))

        # hold_portfolio snapshot
        for s in shares:
            ind = slope_s.get(s, np.nan)
            hp_rows.append(dict(
                date=date, stk_bbg=s,
                signal=1 if (pd.notna(ind) and ind > 0) else -1,
                indicator=float(ind) if pd.notna(ind) else np.nan,
                t=1,
            ))

    # ---- performance ----
    perf = pd.DataFrame(perf_rows).set_index('date')
    perf['p_ret'] = (
        (perf['tlt_pl'] - perf['tlt_pl'].shift(1)) /
        perf['mv'].shift(1).replace(0, np.nan)
    )
    perf.loc[perf.index[0], 'p_ret'] = (
        perf.loc[perf.index[0], 'tlt_pl'] / ini_amt
    )
    perf['p_ret'] = perf['p_ret'].fillna(0).clip(-0.6, 0.6)
    perf['p_ret_cul'] = (1 + perf['p_ret']).cumprod()
    perf['b_ret_cul'] = (1 + perf['b_ret']).cumprod()
    perf = perf[['unreal_pl','real_pl','dvd','cost','mv','tlt_pl',
                 'p_ret','b_ret','p_ret_cul','b_ret_cul']]

    # ---- performance_year ----
    yr_idx = perf.groupby(perf.index.year).tail(1).index
    py = perf.loc[yr_idx, ['p_ret_cul','b_ret_cul']].copy()
    py['p_ret'] = py['p_ret_cul'] / py['p_ret_cul'].shift(1) - 1
    py['b_ret'] = py['b_ret_cul'] / py['b_ret_cul'].shift(1) - 1
    py.loc[py.index[0], 'p_ret'] = py.loc[py.index[0], 'p_ret_cul'] - 1
    py.loc[py.index[0], 'b_ret'] = py.loc[py.index[0], 'b_ret_cul'] - 1
    py['alpha'] = py['p_ret'] - py['b_ret']

    # ---- performance_tlt ----
    n_yr = max(len(py), 1)

    def _mdd(s):
        rm = s.cummax()
        return ((s - rm) / rm).min()

    pt = pd.DataFrame(
        index=['p','b'],
        columns=['ret','vol','r/v','max_ret','min_ret','turn_over','MDD','stp_loss'],
        data=0.0,
    )
    pt.loc['p','ret']       = perf['p_ret_cul'].iloc[-1] ** (1/n_yr) - 1
    pt.loc['b','ret']       = perf['b_ret_cul'].iloc[-1] ** (1/n_yr) - 1
    pt.loc['p','vol']       = perf['p_ret'].std() * np.sqrt(252)
    pt.loc['b','vol']       = perf['b_ret'].std() * np.sqrt(252)
    pt.loc['p','r/v']       = (pt.loc['p','ret'] / pt.loc['p','vol']
                                if pt.loc['p','vol'] else 0)
    pt.loc['b','r/v']       = (pt.loc['b','ret'] / pt.loc['b','vol']
                                if pt.loc['b','vol'] else 0)
    pt.loc['p','max_ret']   = perf['p_ret_cul'].max() - 1
    pt.loc['p','min_ret']   = perf['p_ret_cul'].min() - 1
    pt.loc['b','max_ret']   = perf['b_ret_cul'].max() - 1
    pt.loc['b','min_ret']   = perf['b_ret_cul'].min() - 1
    pt.loc['p','MDD']       = _mdd(perf['p_ret_cul'])
    pt.loc['b','MDD']       = _mdd(perf['b_ret_cul'])
    nav_avg                 = max(ini_amt + perf['tlt_pl'].mean(), 1)
    pt.loc['p','turn_over'] = (turnover / 2) / nav_avg / max(len(trade_dates), 1) * 250
    pt.loc['p','stp_loss']  = float(stop_count)

    # ---- hold_portfolio ----
    hp = (pd.DataFrame(hp_rows)
          if hp_rows
          else pd.DataFrame(columns=['date','stk_bbg','signal','indicator','t']))

    # ---- trade (index = date) ----
    if trade_list:
        tr = pd.DataFrame(trade_list, columns=['date','stk_bbg','t_shares','t_amt'])
        tr = tr.set_index('date')
    else:
        tr = pd.DataFrame(columns=['stk_bbg','t_shares','t_amt'])
        tr.index.name = 'date'

    # ---- holdings (final state) ----
    last_di = d2i.get(trade_dates[-1]) if trade_dates else None
    last_px = px_df.iloc[last_di] if last_di is not None else None
    hrows = []
    for s in stk_list:
        sh  = shares.get(s, 0.0)
        cb  = cost_basis.get(s, 0.0)
        pxm = float(last_px[s]) if last_px is not None else 0.0
        mv_s = sh * pxm
        hrows.append({
            'stk_bbg': s, 'shares': sh, 'cost': cb, 'px_m': pxm,
            'mv': mv_s, 'unreal_pl': mv_s - cb,
            'ret': (mv_s/cb - 1) if cb else 0.0,
            'dvd': 0.0, 'real_pl': real_pl, 'tlt_pl': mv_s - cb + real_pl,
        })
    hld = pd.DataFrame(hrows).set_index('stk_bbg')

    return pt, py, perf, hp, tr, hld

# ===============================================================
# §5  主程式
# ===============================================================

if __name__ == '__main__':

    # [1] 生成市場資料
    print("\n[1/5] Generating synthetic market data ...")
    t0 = time.time()
    px_df, idx_df, all_dates = generate_market()
    all_dates_list  = list(all_dates)
    trade_dates_all = [d for d in all_dates if d >= pd.Timestamp(START_TRADE)]
    print(f"      Stocks: {len(UNIVERSE)}  |  Total days: {len(all_dates)}"
          f"  |  Trade days: {len(trade_dates_all)}  ({time.time()-t0:.1f}s)")

    # [2] 計算主要 slope
    print(f"\n[2/5] Computing slope indicator (period={SLOPE_PERIOD}) ...")
    t0 = time.time()
    slope_main = compute_slopes(px_df.values, SLOPE_PERIOD)
    print(f"      Done ({time.time()-t0:.1f}s)")

    # [3] 單次回測
    print(f"\n[3/5] Single backtest (period={SLOPE_PERIOD}, crt_chg={CRT_CHG}) ...")
    t0 = time.time()
    pt, py, perf, hp, tr, hld = run_backtest(
        px_df, idx_df, slope_main, all_dates_list, trade_dates_all,
        stk_num=STK_NUM, stop_loss=STOP_LOSS, crt_chg=CRT_CHG, ini_amt=INI_AMT,
    )
    p_ann  = pt.loc['p','ret']
    b_ann  = pt.loc['b','ret']
    p_cul  = perf['p_ret_cul'].iloc[-1] - 1
    b_cul  = perf['b_ret_cul'].iloc[-1] - 1
    n_alp  = (py['alpha'] > 0).sum()
    print(f"      Strategy ann. ret: {p_ann*100:+.2f}%  |  Benchmark: {b_ann*100:+.2f}%")
    print(f"      Cumulative ret:     {p_cul*100:+.2f}%  |  Benchmark: {b_cul*100:+.2f}%")
    print(f"      Sharpe: {pt.loc['p','r/v']:.2f}  |  MDD: {pt.loc['p','MDD']*100:.2f}%"
          f"  |  Alpha years: {n_alp}/{len(py)}")
    print(f"      Stop-loss triggers: {int(pt.loc['p','stp_loss'])}"
          f"  |  Holdings rows: {len(hp)}  |  Trade rows: {len(tr)}")
    print(f"      Done ({time.time()-t0:.1f}s)")

    meta_bt = dict(
        index=INDEX_NAME, stk_num=STK_NUM, ini_amt=INI_AMT,
        stop_loss=STOP_LOSS, period=SLOPE_PERIOD, crt_chg=CRT_CHG,
        start_date=START_TRADE, end_date=END_DATE,
    )

    # [4] 最佳化網格搜尋
    n_comb = len(OPT_PERIODS) * len(OPT_CRTS)
    print(f"\n[4/5] Optimization grid search"
          f" ({len(OPT_PERIODS)} periods x {len(OPT_CRTS)} crt_chg = {n_comb} combos) ...")
    t0 = time.time()

    # 預計算各期間 slope
    slope_cache = {}
    for p in OPT_PERIODS:
        print(f"      Computing slopes period={p} ...", end='\r')
        slope_cache[p] = compute_slopes(px_df.values, p)

    opt_rows = []
    for p in OPT_PERIODS:
        sl = slope_cache[p]
        for c in OPT_CRTS:
            _, py_o, perf_o, _, _, _ = run_backtest(
                px_df, idx_df, sl, all_dates_list, trade_dates_all,
                stk_num=STK_NUM, stop_loss=STOP_LOSS, crt_chg=c, ini_amt=INI_AMT,
            )
            opt_rows.append({
                'para_period':  p,
                'para_crt_chg': c,
                'ret':          float(perf_o['p_ret_cul'].iloc[-1]),   # factor (matches original code)
                'alpha_year':   float((py_o['alpha'] > 0).sum()),
            })
            print(f"      period={p:3d}  crt={c:.4f}"
                  f"  cumul_ret={(perf_o['p_ret_cul'].iloc[-1]-1)*100:+.1f}%"
                  f"  alpha_yr={(py_o['alpha']>0).sum()}", end='\r')

    df_opt = pd.DataFrame(opt_rows)
    best   = df_opt.sort_values(['alpha_year','ret'], ascending=[False,False]).iloc[0]
    best_p = int(best['para_period'])
    best_c = float(best['para_crt_chg'])
    print(f"\n      Best combo: period={best_p}  crt_chg={best_c:.4f}"
          f"  cumul={(best['ret']-1)*100:+.2f}%  alpha_yr={int(best['alpha_year'])}")
    print(f"      Done ({time.time()-t0:.1f}s)")

    # 用最佳參數重跑取得完整明細
    print(f"\n      Re-running with best params for full detail ...")
    pt_opt, py_opt, perf_opt, hp_opt, tr_opt, hld_opt = run_backtest(
        px_df, idx_df, slope_cache[best_p], all_dates_list, trade_dates_all,
        stk_num=STK_NUM, stop_loss=STOP_LOSS, crt_chg=best_c, ini_amt=INI_AMT,
    )

    meta_opt = dict(
        index=INDEX_NAME, stk_num=STK_NUM, ini_amt=INI_AMT,
        stop_loss=STOP_LOSS, best_period=best_p, best_crt_chg=best_c,
        start_date=START_TRADE, end_date=END_DATE,
    )

    # [5] 輸出報表
    print(f"\n[5/5] Building interactive HTML reports ...")

    r1 = build_backtest_report(
        performance=perf,
        performance_year=py,
        performance_tlt=pt,
        hold_portfolio=hp,
        trade=tr,
        holdings=hld,
        meta=meta_bt,
        output_path='slope_backtest_report.html',
        auto_open=True,
    )
    print(f"      [OK] Single backtest report: {r1}")

    r2 = build_report(
        df_opt=df_opt,
        performance=perf_opt,
        performance_year=py_opt,
        performance_tlt=pt_opt,
        hold_portfolio=hp_opt,
        trade=tr_opt,
        meta=meta_opt,
        output_path='slope_optimize_report.html',
        auto_open=True,
    )
    print(f"      [OK] Optimization report:    {r2}")

    print("\nDone! Two HTML reports should open automatically in your browser.")
    print("=" * 60)
