# slope_demo_report.py
# -*- coding: utf-8 -*-
"""
Slope 策略互動式回測報表產生器
---
公開介面:
  build_report(...)           → 最佳化回測 HTML 報表（含最佳參數完整回測）
  build_backtest_report(...)  → 單次回測 HTML 報表
"""

import os, webbrowser
import numpy as np
import pandas as pd
import plotly.graph_objects as go
from plotly.subplots import make_subplots


# ═══════════════════════════════════════════════════════════════════════════════
# §1  格式化工具
# ═══════════════════════════════════════════════════════════════════════════════

def _p(v, d=2):
    """數值 → 百分比字串 (e.g. 0.123 → '12.30%')"""
    try:
        if pd.isna(v): return 'N/A'
    except Exception: pass
    return f"{float(v)*100:.{d}f}%"

def _n(v, d=2):
    """數值 → 固定小數字串"""
    try:
        if pd.isna(v): return 'N/A'
    except Exception: pass
    return f"{float(v):.{d}f}"

def _a(v, d=0):
    """數值 → 千位分隔字串"""
    try:
        if pd.isna(v): return 'N/A'
    except Exception: pass
    return f"{float(v):,.{d}f}"

def _dt(v):
    """日期/NaT → YYYY-MM-DD 字串"""
    try:
        if pd.isna(v): return '─'
    except Exception: pass
    if hasattr(v, 'strftime'): return v.strftime('%Y-%m-%d')
    return str(v)[:10]

def _cls(v, good_pos=True):
    """數值 → CSS class (pos/neg/'')"""
    try:
        f = float(v)
        if np.isnan(f): return ''
        if f > 0: return 'pos' if good_pos else 'neg'
        if f < 0: return 'neg' if good_pos else 'pos'
    except Exception: pass
    return ''

def _sg(v):
    """取 Series/scalar 安全值"""
    try:
        if isinstance(v, pd.Series): v = v.iloc[0]
        if pd.isna(v): return np.nan
        return float(v)
    except Exception: return np.nan


# ═══════════════════════════════════════════════════════════════════════════════
# §2  交易紀錄計算
# ═══════════════════════════════════════════════════════════════════════════════

def _prep_trade(trade):
    """確保 trade DataFrame 含 date 欄（非 index）。"""
    if trade is None: return pd.DataFrame(columns=['date','stk_bbg','t_shares','t_amt'])
    if isinstance(trade, list) and len(trade) == 0:
        return pd.DataFrame(columns=['date','stk_bbg','t_shares','t_amt'])
    tr = trade.copy()
    if tr.index.name == 'date' or (not isinstance(tr.index, pd.RangeIndex) and 'date' not in tr.columns):
        tr = tr.reset_index()
    return tr

def _prep_hp(hp):
    """確保 hold_portfolio 有標準欄位且含 date 欄。"""
    if hp is None: return pd.DataFrame(columns=['date','stk_bbg','signal','indicator'])
    if isinstance(hp, list) and len(hp) == 0:
        return pd.DataFrame(columns=['date','stk_bbg','signal','indicator'])
    h = hp.copy()
    if isinstance(h.index, pd.DatetimeIndex):
        h = h.reset_index()
    if 'date' not in h.columns:
        h = h.reset_index()
    return h


def _compute_trade_log(hold_portfolio, trade):
    """
    從 hold_portfolio 與 trade 推導每筆進出場明細。

    回傳 DataFrame 欄位:
        Ticker, 入場日, 出場日, 持有天數, 入場金額, 出場金額, 損益, 報酬率, 勝負
    """
    hp = _prep_hp(hold_portfolio)
    tr = _prep_trade(trade)
    if hp.empty: return pd.DataFrame()

    records, entry_dict = [], {}
    for date in sorted(hp['date'].unique()):
        today = set(hp.loc[hp['date'] == date, 'stk_bbg'].tolist())
        prev  = set(entry_dict.keys())

        for stk in (today - prev):
            row = tr[(tr['date'] == date) & (tr['stk_bbg'] == stk)]
            amt = float(row['t_amt'].iloc[0]) if not row.empty else np.nan
            entry_dict[stk] = {'entry_date': date, 'entry_amt': amt}

        for stk in (prev - today):
            info     = entry_dict.pop(stk)
            row      = tr[(tr['date'] == date) & (tr['stk_bbg'] == stk)]
            exit_amt = abs(float(row['t_amt'].iloc[0])) if not row.empty else np.nan
            cost     = info['entry_amt']
            profit   = (exit_amt - cost) if (pd.notna(exit_amt) and pd.notna(cost)) else np.nan
            ret      = profit / abs(cost) if (pd.notna(profit) and cost) else np.nan
            days     = int((date - info['entry_date']) / np.timedelta64(1, 'D'))
            records.append(dict(
                Ticker=stk, 入場日=info['entry_date'], 出場日=date,
                持有天數=days, 入場金額=cost, 出場金額=exit_amt,
                損益=profit, 報酬率=ret,
                勝負=('勝' if (pd.notna(profit) and profit > 0) else
                     '敗' if (pd.notna(profit) and profit < 0) else '平手')
            ))

    for stk, info in entry_dict.items():
        max_date = hp['date'].max()
        days = int((max_date - info['entry_date']) / np.timedelta64(1, 'D'))
        records.append(dict(
            Ticker=stk, 入場日=info['entry_date'], 出場日=None,
            持有天數=days, 入場金額=info['entry_amt'],
            出場金額=np.nan, 損益=np.nan, 報酬率=np.nan, 勝負='持有中'
        ))

    return pd.DataFrame(records)


def _compute_stock_profile(trade_log, hp_orig, trade):
    """
    每檔股票統計:
        買進次數、賣出次數、完成交易、勝出、勝率、平均持有天數、最新Slope分數、最新訊號
    """
    hp = _prep_hp(hp_orig)
    tr = _prep_trade(trade)
    if trade_log is None or trade_log.empty: return pd.DataFrame()

    rows = []
    for stk in sorted(trade_log['Ticker'].unique()):
        sub  = trade_log[trade_log['Ticker'] == stk]
        done = sub[sub['勝負'].isin(['勝', '敗', '平手'])]
        n_buy  = len(tr[(tr['stk_bbg'] == stk) & (tr['t_shares'] > 0)])
        n_sell = len(tr[(tr['stk_bbg'] == stk) & (tr['t_shares'] < 0)])
        n      = len(done)
        wins   = (done['勝負'] == '勝').sum()
        wr     = wins / n if n > 0 else np.nan
        ad     = done['持有天數'].mean() if not done.empty else np.nan
        hp_s   = hp[hp['stk_bbg'] == stk] if not hp.empty else pd.DataFrame()
        li     = float(hp_s.sort_values('date')['indicator'].iloc[-1]) if not hp_s.empty else np.nan
        rows.append(dict(
            Ticker=stk,
            買進次數=n_buy, 賣出次數=n_sell,
            完成交易=n, 勝出次數=wins,
            勝率=round(wr, 4)   if pd.notna(wr) else np.nan,
            平均持有天數=round(ad, 1) if pd.notna(ad) else np.nan,
            最新Slope分數=round(li, 6)  if pd.notna(li) else np.nan,
            最新訊號=('多頭' if pd.notna(li) and li > 0 else
                    '空頭' if pd.notna(li) and li < 0 else '─')
        ))

    return pd.DataFrame(rows).sort_values('勝率', ascending=False).reset_index(drop=True)


def _trade_summary(trade_log):
    """從 trade_log 計算簡要統計（回傳 dict）。"""
    if trade_log is None or trade_log.empty:
        return {}
    done = trade_log[trade_log['勝負'].isin(['勝', '敗', '平手'])]
    n    = len(done)
    if n == 0: return {}
    wins = (done['勝負'] == '勝').sum()
    lose = (done['勝負'] == '敗').sum()
    wr   = wins / n
    ad   = done['持有天數'].mean()
    md   = done['持有天數'].max()
    avg_ret_w = done.loc[done['勝負']=='勝','報酬率'].mean() if wins else np.nan
    avg_ret_l = done.loc[done['勝負']=='敗','報酬率'].mean() if lose else np.nan
    return dict(
        總交易次數=n, 勝出次數=int(wins), 虧損次數=int(lose),
        勝率=wr, 平均持有天數=round(ad,1), 最大持有天數=int(md),
        平均獲利率=avg_ret_w, 平均虧損率=avg_ret_l
    )


# ═══════════════════════════════════════════════════════════════════════════════
# §3  Plotly 圖表
# ═══════════════════════════════════════════════════════════════════════════════

_LAYOUT = dict(
    template='plotly_white',
    font=dict(family="'Segoe UI',Arial,sans-serif", size=12),
    margin=dict(l=60, r=20, t=50, b=42),
    legend=dict(orientation='h', yanchor='bottom', y=1.02, xanchor='right', x=1)
)


def _div(fig, h=None):
    if h: fig.update_layout(height=h)
    return fig.to_html(full_html=False, include_plotlyjs=False,
                       config={'displayModeBar': True, 'responsive': True})


def _chart_cum_ret(perf):
    """累積報酬率 + 策略回撤雙列圖。"""
    d  = perf.index.tolist()
    pc = (perf['p_ret_cul'] - 1) * 100
    bc = (perf['b_ret_cul'] - 1) * 100
    rm = perf['p_ret_cul'].cummax()
    dd = (perf['p_ret_cul'] - rm) / rm * 100

    fig = make_subplots(
        rows=2, cols=1, shared_xaxes=True, row_heights=[0.68, 0.32],
        vertical_spacing=0.06,
        subplot_titles=['累積報酬率 (%)', '策略最大回撤 (%)']
    )
    fig.add_trace(go.Scatter(x=d, y=pc.tolist(), name='策略',
                             line=dict(color='#1565C0', width=2.2)), row=1, col=1)
    fig.add_trace(go.Scatter(x=d, y=bc.tolist(), name='S&P 500',
                             line=dict(color='#F57F17', width=1.8, dash='dot')), row=1, col=1)
    fig.add_trace(go.Scatter(x=d, y=dd.tolist(), name='回撤', showlegend=False,
                             fill='tozeroy', mode='lines',
                             line=dict(color='#C62828', width=1),
                             fillcolor='rgba(198,40,40,.15)'), row=2, col=1)
    fig.update_layout(**_LAYOUT, height=520)
    fig.update_yaxes(ticksuffix='%', row=1, col=1)
    fig.update_yaxes(ticksuffix='%', row=2, col=1)
    return _div(fig)


def _chart_annual(py):
    """逐年報酬率分組柱狀圖。"""
    years = [str(y.year) for y in py.index]
    p_r   = (py['p_ret'] * 100).round(2).tolist()
    b_r   = (py['b_ret'] * 100).round(2).tolist()
    cp = ['#1565C0' if v >= 0 else '#C62828' for v in p_r]
    cb = ['#EF6C00' if v >= 0 else '#7B1FA2' for v in b_r]

    fig = go.Figure()
    fig.add_trace(go.Bar(name='策略', x=years, y=p_r, marker_color=cp,
                         text=[f"{v:.1f}%" for v in p_r],
                         textposition='outside', textfont=dict(size=11)))
    fig.add_trace(go.Bar(name='S&P 500', x=years, y=b_r, marker_color=cb,
                         text=[f"{v:.1f}%" for v in b_r],
                         textposition='outside', textfont=dict(size=11)))
    fig.update_layout(**_LAYOUT, barmode='group', height=380,
                      yaxis=dict(ticksuffix='%'),
                      bargap=0.22, bargroupgap=0.06)
    return _div(fig)


def _chart_opt_heatmap(df_opt):
    """最佳化參數熱圖 (累積報酬率 & Alpha勝出年數)。"""
    periods = sorted(df_opt['para_period'].unique())
    crts    = sorted(df_opt['para_crt_chg'].unique(), reverse=True)

    z_ret, z_alpha = [], []
    for crt in crts:
        rr, ra = [], []
        for p in periods:
            m = df_opt[
                (df_opt['para_period'] == p) &
                (np.abs(df_opt['para_crt_chg'] - crt) < 1e-9)
            ]
            if not m.empty:
                rr.append(round((float(m['ret'].iloc[0]) - 1) * 100, 2))
                ra.append(int(m['alpha_year'].iloc[0]))
            else:
                rr.append(None); ra.append(None)
        z_ret.append(rr); z_alpha.append(ra)

    yl = [f"{c:.4f}" for c in crts]
    xl = [str(int(p)) for p in periods]

    fig = make_subplots(rows=1, cols=2, horizontal_spacing=0.14,
                        subplot_titles=['累積報酬率 (%)', 'Alpha 勝出年數'])
    fig.add_trace(go.Heatmap(z=z_ret, x=xl, y=yl, colorscale='RdYlGn',
                             text=[[f"{v:.1f}" if v is not None else '' for v in r] for r in z_ret],
                             texttemplate="%{text}",
                             colorbar=dict(x=0.44, len=0.9, title='%')), row=1, col=1)
    fig.add_trace(go.Heatmap(z=z_alpha, x=xl, y=yl, colorscale='Blues',
                             text=[[str(v) if v is not None else '' for v in r] for r in z_alpha],
                             texttemplate="%{text}",
                             colorbar=dict(x=1.01, len=0.9, title='年')), row=1, col=2)
    fig.update_layout(**_LAYOUT, height=440,
                      xaxis_title='回測期間 (天)',  xaxis2_title='回測期間 (天)',
                      yaxis_title='換股門檻 (crt_chg)')
    return _div(fig)


def _chart_opt_scatter(df_opt):
    """最佳化結果散點圖 (x=累積報酬率, y=Alpha年數)。"""
    ret_pct = ((df_opt['ret'] - 1) * 100).tolist()
    fig = go.Figure(go.Scatter(
        x=ret_pct,
        y=df_opt['alpha_year'].astype(int).tolist(),
        mode='markers',
        marker=dict(size=10, color=ret_pct,
                    colorscale='RdYlGn', showscale=True,
                    colorbar=dict(title='累積報酬%', len=0.8)),
        text=[f"Period={int(r['para_period'])}, Crt={r['para_crt_chg']:.4f}"
              for _, r in df_opt.iterrows()],
        hovertemplate='%{text}<br>報酬率: %{x:.2f}%<br>Alpha年數: %{y}<extra></extra>'
    ))
    fig.update_layout(**_LAYOUT, height=350,
                      xaxis_title='累積報酬率 (%)', yaxis_title='Alpha 勝出年數')
    return _div(fig)


# ═══════════════════════════════════════════════════════════════════════════════
# §4  CSS / JS / HTML 骨架
# ═══════════════════════════════════════════════════════════════════════════════

_CSS = """
:root{--accent:#1565C0;--accent2:#42A5F5;--accent-light:#e3f2fd;--bg:#f4f6f9;}
*{box-sizing:border-box;}
body{background:var(--bg);font-family:'Segoe UI',Arial,sans-serif;color:#263238;}
a{color:var(--accent);}

/* ── Header ─────────────────────────────────── */
.rpt-title{font-size:1.6rem;font-weight:800;color:#0d47a1;letter-spacing:.3px;}
.rpt-sub{font-size:.82rem;color:#607D8B;margin-top:3px;}

/* ── KPI Cards ───────────────────────────────── */
.kpi-row{display:flex;flex-wrap:wrap;gap:10px;margin-bottom:20px;}
.kpi-card{flex:1 1 145px;min-width:130px;background:#fff;border-radius:12px;
          padding:15px 14px 12px;box-shadow:0 2px 10px rgba(0,0,0,.07);text-align:center;
          border-top:3px solid var(--accent);}
.kpi-card.bench{border-top-color:#EF6C00;}
.kpi-label{font-size:.68rem;font-weight:700;color:#78909C;text-transform:uppercase;
           letter-spacing:.7px;margin-bottom:5px;}
.kpi-val{font-size:1.42rem;font-weight:800;line-height:1.15;}
.kpi-bm{font-size:.72rem;color:#90A4AE;margin-top:3px;}

/* ── Colors ──────────────────────────────────── */
.pos{color:#2e7d32!important;}
.neg{color:#b71c1c!important;}

/* ── Tab navigation ──────────────────────────── */
.nav-tabs{border-bottom:2px solid #dde3ee;flex-wrap:nowrap;overflow-x:auto;}
.nav-tabs .nav-link{font-size:.84rem;font-weight:600;color:#607D8B;border:none;
                    padding:9px 15px;border-radius:0;white-space:nowrap;}
.nav-tabs .nav-link.active{color:var(--accent);border-bottom:3px solid var(--accent);
                            background:transparent;}
.nav-tabs .nav-link:hover{color:var(--accent);background:var(--accent-light);}
.tab-content{background:#fff;border:1px solid #dde3ee;border-top:none;
             border-radius:0 0 10px 10px;padding:18px 18px 22px;}

/* ── Section cards ───────────────────────────── */
.sec-card{background:#fff;border-radius:10px;
          box-shadow:0 1px 8px rgba(0,0,0,.06);padding:16px;margin-bottom:14px;}
.sec-title{font-size:.88rem;font-weight:700;color:var(--accent);
           margin-bottom:11px;padding-bottom:7px;
           border-bottom:2px solid var(--accent-light);}

/* ── Metric table (績效 vs 大盤) ─────────────── */
.mtbl{width:100%;font-size:.86rem;border-collapse:collapse;}
.mtbl thead th{background:#ecf3fb;color:#37474F;font-weight:700;
               padding:9px 16px;text-align:left;border-bottom:2px solid #c5d9f0;}
.mtbl tbody tr:nth-child(even){background:#f8faff;}
.mtbl tbody tr:hover{background:#e3f2fd;}
.mtbl td{padding:8px 16px;border-bottom:1px solid #edf0f7;vertical-align:middle;}
.mtbl td.lbl{font-weight:600;color:#455A64;width:200px;}
.mtbl td.vp{font-weight:700;font-size:.92rem;}
.mtbl td.vb{font-size:.88rem;color:#546E7A;}

/* ── Data tables ──────────────────────────────── */
.tbl{width:100%;border-collapse:collapse;font-size:.8rem;}
.tbl thead th{background:var(--accent);color:#fff;padding:8px 10px;
              text-align:center;white-space:nowrap;
              position:sticky;top:0;z-index:2;cursor:pointer;user-select:none;}
.tbl thead th:hover{background:#1976D2;}
.tbl tbody tr:nth-child(even){background:#f8faff;}
.tbl tbody tr:hover{background:#e3f2fd;}
.tbl tbody td{padding:6px 10px;border-bottom:1px solid #edf0f7;
              text-align:right;white-space:nowrap;}
.tbl tbody td:first-child{text-align:left;font-weight:600;}
.tbl-wrap{max-height:490px;overflow-y:auto;border-radius:8px;
          box-shadow:0 1px 6px rgba(0,0,0,.08);}

/* ── Search box ──────────────────────────────── */
.srch{max-width:260px;font-size:.8rem !important;}

/* ── Badges ──────────────────────────────────── */
.bw{background:#e8f5e9;color:#1b5e20;border-radius:99px;padding:2px 9px;font-size:.76rem;}
.bl{background:#ffebee;color:#b71c1c;border-radius:99px;padding:2px 9px;font-size:.76rem;}
.bh{background:#e3f2fd;color:#0d47a1;border-radius:99px;padding:2px 9px;font-size:.76rem;}
.bq{background:#f3e5f5;color:#6a1b9a;border-radius:99px;padding:2px 9px;font-size:.76rem;}

/* ── Summary strip ───────────────────────────── */
.sum-strip{display:flex;flex-wrap:wrap;gap:8px;margin-bottom:14px;}
.sum-chip{background:#f4f8ff;border:1px solid #d0ddf7;border-radius:8px;
          padding:6px 14px;font-size:.8rem;}
.sum-chip b{color:var(--accent);}

/* ── Opt best card ───────────────────────────── */
.best-card{background:linear-gradient(135deg,#1565C0 0%,#42A5F5 100%);
           border-radius:14px;padding:22px 24px;color:#fff;margin-bottom:16px;}
.best-row{display:flex;flex-wrap:wrap;gap:20px;}
.best-item{text-align:center;}
.best-item .bc-val{font-size:1.55rem;font-weight:800;line-height:1.1;}
.best-item .bc-lbl{font-size:.72rem;opacity:.85;margin-top:3px;}

/* ── Settings ────────────────────────────────── */
.stbl td{padding:8px 16px;border-bottom:1px solid #f0f4f8;font-size:.87rem;}
.stbl td:first-child{color:#607D8B;font-weight:600;width:200px;}

/* ── Annual table alpha column ───────────────── */
.alpha-pos{color:#2e7d32;font-weight:700;}
.alpha-neg{color:#b71c1c;font-weight:700;}
"""

_JS = r"""
function filterTable(sid, tid) {
    var q = document.getElementById(sid).value.toLowerCase();
    document.querySelectorAll('#' + tid + ' tbody tr').forEach(function(r) {
        r.style.display = r.innerText.toLowerCase().indexOf(q) >= 0 ? '' : 'none';
    });
}
function sortTable(th, tid) {
    var tbl  = document.getElementById(tid);
    var idx  = th.cellIndex;
    var asc  = th.dataset.asc !== 'true';
    th.dataset.asc = asc;
    var rows = Array.from(tbl.querySelectorAll('tbody tr'));
    rows.sort(function(a, b) {
        var av = a.cells[idx].innerText.replace(/[%,]/g,'').trim();
        var bv = b.cells[idx].innerText.replace(/[%,]/g,'').trim();
        var an = parseFloat(av), bn = parseFloat(bv);
        if (!isNaN(an) && !isNaN(bn)) return asc ? an - bn : bn - an;
        return asc ? av.localeCompare(bv, 'zh') : bv.localeCompare(av, 'zh');
    });
    tbl.querySelectorAll('thead th').forEach(function(h) {
        h.textContent = h.textContent.replace(/ [▲▼]$/, '');
    });
    rows.forEach(function(r) { tbl.querySelector('tbody').appendChild(r); });
    th.textContent += (asc ? ' ▲' : ' ▼');
}
"""

def _html_head(title):
    return (
        '<!DOCTYPE html>\n<html lang="zh-TW">\n<head>\n'
        '<meta charset="UTF-8">'
        '<meta name="viewport" content="width=device-width,initial-scale=1">\n'
        f'<title>{title}</title>\n'
        '<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">\n'
        '<script src="https://cdn.plot.ly/plotly-2.35.2.min.js" charset="utf-8"></script>\n'
        f'<style>{_CSS}</style>\n'
        '</head>\n<body>\n<div class="container-fluid px-4 py-3">\n'
    )

def _html_tail():
    return (
        '</div>\n'
        '<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>\n'
        f'<script>{_JS}</script>\n'
        '</body>\n</html>'
    )

def _tabs_html(tab_list):
    """
    tab_list: [(tid, label, html_content), ...]
    """
    nav = '<ul class="nav nav-tabs mt-3 mb-0" role="tablist">\n'
    panes = '<div class="tab-content">\n'
    for i, (tid, label, content) in enumerate(tab_list):
        active = ' active' if i == 0 else ''
        show   = ' show active' if i == 0 else ''
        nav += (
            f'  <li class="nav-item" role="presentation">'
            f'<button class="nav-link{active}" id="{tid}-tab" data-bs-toggle="tab" '
            f'data-bs-target="#{tid}" type="button" role="tab">{label}</button>'
            f'</li>\n'
        )
        panes += (
            f'<div class="tab-pane fade{show}" id="{tid}" role="tabpanel">\n'
            f'{content}\n</div>\n'
        )
    nav   += '</ul>\n'
    panes += '</div>\n'
    return nav + panes


def _tbl(df, tid, sid=None, fmt=None, cls_fn=None, badge=None):
    """
    DataFrame → 互動式 HTML 表格。
    fmt     = {col: fn(v) → str}
    cls_fn  = {col: fn(v) → css_class}
    badge   = {col: {val_str: badge_class}}
    """
    fmt    = fmt    or {}
    cls_fn = cls_fn or {}
    badge  = badge  or {}

    def render(c, v):
        try: na = pd.isna(v)
        except Exception: na = False
        if na: return '─'
        if c in fmt: return fmt[c](v)
        if hasattr(v, 'strftime'): return v.strftime('%Y-%m-%d')
        return str(v)

    def get_cls(c, v):
        bmap = badge.get(c)
        if bmap:
            return bmap.get(str(v), '')
        fn = cls_fn.get(c)
        if fn: return fn(v)
        return ''

    srch = ''
    if sid:
        srch = (
            f'<div class="mb-2">'
            f'<input class="form-control form-control-sm srch" id="{sid}" '
            f'type="text" placeholder="搜尋 ..." '
            f'oninput="filterTable(\'{sid}\',\'{tid}\')">'
            f'</div>\n'
        )

    thead = ''.join(
        f'<th onclick="sortTable(this,\'{tid}\')">{c}</th>'
        for c in df.columns
    )

    tbody = ''
    for _, row in df.iterrows():
        cells = ''
        for c in df.columns:
            v   = row[c]
            txt = render(c, v)
            css = get_cls(c, v)
            if css:
                cells += f'<td><span class="{css}">{txt}</span></td>'
            else:
                cells += f'<td>{txt}</td>'
        tbody += f'<tr>{cells}</tr>\n'

    return (
        f'{srch}'
        f'<div class="tbl-wrap">'
        f'<table class="tbl" id="{tid}">'
        f'<thead><tr>{thead}</tr></thead>'
        f'<tbody>{tbody}</tbody>'
        f'</table></div>'
    )


# ═══════════════════════════════════════════════════════════════════════════════
# §5  HTML 區塊產生器
# ═══════════════════════════════════════════════════════════════════════════════

def _kpi_html(pp, pb, avg_alpha, total_p, total_b):
    """KPI Cards (上方彙整指標)。"""
    stp = _sg(pp.get('stp_loss', 0))
    items = [
        ('年化報酬率',   _p(pp['ret']),     _p(pb['ret']),     _cls(pp['ret'])),
        ('累積報酬率',   _p(total_p),       _p(total_b),       _cls(total_p)),
        ('Sharpe Ratio', _n(pp['r/v']),    _n(pb['r/v']),    _cls(pp['r/v'])),
        ('最大回撤 MDD', _p(pp['MDD']),     _p(pb['MDD']),     _cls(pp['MDD'], good_pos=False)),
        ('年化波動度',   _p(pp['vol']),     _p(pb['vol']),     ''),
        ('年均 Alpha',   _p(avg_alpha),    '─',              _cls(avg_alpha)),
        ('年化換手率',   _p(pp['turn_over']),'─',             ''),
        ('停損次數',     str(int(stp)) if not np.isnan(stp) else '─', '─', ''),
    ]
    cards = ''
    for label, vp, vb, css in items:
        cards += (
            f'<div class="kpi-card">'
            f'  <div class="kpi-label">{label}</div>'
            f'  <div class="kpi-val {css}">{vp}</div>'
            f'  <div class="kpi-bm">大盤: {vb}</div>'
            f'</div>\n'
        )
    return f'<div class="kpi-row">{cards}</div>\n'


def _metrics_tbl(pp, pb, avg_alpha, total_p, total_b):
    """績效指標對照表。"""
    stp = _sg(pp.get('stp_loss', 0))
    rows_data = [
        ('年化報酬率',    _p(pp['ret']),           _p(pb['ret'])),
        ('累積報酬率',    _p(total_p),             _p(total_b)),
        ('年化波動度',    _p(pp['vol']),            _p(pb['vol'])),
        ('Sharpe Ratio', _n(pp['r/v']),           _n(pb['r/v'])),
        ('最大報酬率',    _p(pp['max_ret']),        _p(pb['max_ret'])),
        ('最小報酬率',    _p(pp['min_ret']),        _p(pb['min_ret'])),
        ('最大回撤 MDD', _p(pp['MDD']),            _p(pb['MDD'])),
        ('年均 Alpha',   _p(avg_alpha),            '─'),
        ('年化換手率',   _p(pp['turn_over']),       '─'),
        ('停損次數',     str(int(stp)) if not np.isnan(stp) else '─', '─'),
    ]
    rows_html = ''
    for lbl, vp, vb in rows_data:
        rows_html += f'<tr><td class="lbl">{lbl}</td><td class="vp">{vp}</td><td class="vb">{vb}</td></tr>\n'
    return (
        '<div class="sec-card">'
        '<div class="sec-title">績效指標對照表</div>'
        '<table class="mtbl">'
        '<thead><tr><th>指標</th><th>策略</th><th>大盤 (S&amp;P 500)</th></tr></thead>'
        f'<tbody>{rows_html}</tbody>'
        '</table></div>\n'
    )


def _annual_tbl(py):
    """逐年績效表。"""
    df = py[['p_ret', 'b_ret', 'alpha', 'p_ret_cul', 'b_ret_cul']].copy()
    df.index = [y.year for y in df.index]
    df.index.name = '年度'
    df = df.reset_index()
    df.columns = ['年度', '策略年報酬率', '大盤年報酬率', 'Alpha', '策略累積報酬率', '大盤累積報酬率']

    def pct(v):
        try:
            return '─' if pd.isna(v) else f"{v*100:.2f}%"
        except Exception: return '─'

    def alpha_cls(v):
        try:
            return 'alpha-pos' if float(v) > 0 else ('alpha-neg' if float(v) < 0 else '')
        except Exception: return ''

    return (
        '<div class="sec-card">'
        '<div class="sec-title">逐年績效明細</div>' +
        _tbl(df, 'tbl_annual',
             fmt={
                 '策略年報酬率': pct, '大盤年報酬率': pct,
                 'Alpha': pct,
                 '策略累積報酬率': lambda v: pct(v - 1) if not pd.isna(v) else '─',
                 '大盤累積報酬率': lambda v: pct(v - 1) if not pd.isna(v) else '─',
             },
             cls_fn={
                 '策略年報酬率': lambda v: _cls(v),
                 '大盤年報酬率': lambda v: _cls(v),
                 'Alpha': alpha_cls,
             }) +
        '</div>\n'
    )


def _daily_perf_tbl(perf):
    """每日績效表。"""
    df = perf[['p_ret', 'b_ret', 'p_ret_cul', 'b_ret_cul',
               'mv', 'cost', 'unreal_pl', 'real_pl', 'tlt_pl']].copy()
    df.index.name = '日期'
    df = df.reset_index()
    df.columns = ['日期', '策略日報酬', '大盤日報酬', '策略累積報酬', '大盤累積報酬',
                  '市值', '成本', '未實現損益', '已實現損益', '總損益']
    df['日期'] = df['日期'].dt.strftime('%Y-%m-%d')

    def pct(v):
        return '─' if pd.isna(v) else f"{v*100:.3f}%"

    def cul_pct(v):
        return '─' if pd.isna(v) else f"{(v-1)*100:.2f}%"

    return (
        '<div class="sec-card">'
        '<div class="sec-title">每日投資組合績效</div>' +
        _tbl(df, 'tbl_daily', sid='srch_daily',
             fmt={
                 '策略日報酬': pct, '大盤日報酬': pct,
                 '策略累積報酬': cul_pct, '大盤累積報酬': cul_pct,
                 '市值': _a, '成本': _a, '未實現損益': _a, '已實現損益': _a, '總損益': _a,
             },
             cls_fn={
                 '策略日報酬': lambda v: _cls(v),
                 '大盤日報酬': lambda v: _cls(v),
                 '未實現損益': lambda v: _cls(v),
                 '已實現損益': lambda v: _cls(v),
                 '總損益': lambda v: _cls(v),
             }) +
        '</div>\n'
    )


def _holdings_tbl(trade_log):
    """持倉明細表：每筆進出場紀錄。"""
    if trade_log is None or trade_log.empty:
        return '<div class="sec-card"><div class="sec-title">持倉明細</div><p class="text-muted small">無持倉資料。</p></div>'

    df = trade_log[[
        'Ticker', '入場日', '出場日', '持有天數',
        '入場金額', '出場金額', '損益', '報酬率', '勝負'
    ]].copy()

    badge_map = {'勝負': {'勝': 'bw', '敗': 'bl', '持有中': 'bh', '平手': 'bq'}}

    return (
        '<div class="sec-card">'
        '<div class="sec-title">持倉明細（進出場紀錄）</div>' +
        _tbl(df, 'tbl_hold', sid='srch_hold',
             fmt={
                 '入場日': _dt, '出場日': _dt,
                 '入場金額': _a, '出場金額': _a, '損益': _a,
                 '報酬率': lambda v: _p(v) if pd.notna(v) else '─',
             },
             cls_fn={
                 '損益': lambda v: _cls(v),
                 '報酬率': lambda v: _cls(v),
             },
             badge=badge_map) +
        '</div>\n'
    )


def _trade_tbl(trade_log, trade):
    """換股紀錄：摘要統計 + 原始買賣明細。"""
    summ = _trade_summary(trade_log)
    strip = ''
    if summ:
        items = [
            ('總交易次數', str(summ.get('總交易次數', '─'))),
            ('勝出次數',   str(summ.get('勝出次數', '─'))),
            ('虧損次數',   str(summ.get('虧損次數', '─'))),
            ('勝率',       _p(summ.get('勝率', np.nan))),
            ('平均持有天數', str(summ.get('平均持有天數', '─'))),
            ('最大持有天數', str(summ.get('最大持有天數', '─'))),
            ('平均獲利率', _p(summ.get('平均獲利率', np.nan))),
            ('平均虧損率', _p(summ.get('平均虧損率', np.nan))),
        ]
        strip = '<div class="sum-strip">' + ''.join(
            f'<div class="sum-chip">{k}: <b>{v}</b></div>' for k, v in items
        ) + '</div>\n'

    tr = _prep_trade(trade)
    if tr.empty:
        detail = '<p class="text-muted small">無交易資料。</p>'
    else:
        df = tr[['date', 'stk_bbg', 't_shares', 't_amt']].copy()
        df['type'] = df['t_shares'].apply(lambda x: '買進' if x > 0 else '賣出')
        df = df.sort_values('date', ascending=False)
        df.columns = ['日期', 'Ticker', '股數', '金額', '方向']
        df = df[['日期', 'Ticker', '方向', '股數', '金額']]
        detail = _tbl(df, 'tbl_trade', sid='srch_trade',
                      fmt={
                          '日期': _dt,
                          '股數': lambda v: _a(v, 0),
                          '金額': _a,
                      },
                      badge={'方向': {'買進': 'bw', '賣出': 'bl'}})

    return (
        '<div class="sec-card">'
        '<div class="sec-title">交易統計摘要</div>'
        + strip + '</div>\n'
        '<div class="sec-card">'
        '<div class="sec-title">買賣交易明細</div>'
        + detail + '</div>\n'
    )


def _stock_prof_tbl(sp):
    """個股分析表：勝率、買賣次數、持有天數、Slope 訊號。"""
    if sp is None or sp.empty:
        return '<div class="sec-card"><div class="sec-title">個股分析</div><p class="text-muted small">無資料。</p></div>'

    df = sp.copy()
    df['勝率'] = df['勝率'].apply(lambda v: f"{v*100:.1f}%" if pd.notna(v) else '─')

    badge_map = {'最新訊號': {'多頭': 'bw', '空頭': 'bl', '─': 'bq'}}

    return (
        '<div class="sec-card">'
        '<div class="sec-title">個股統計分析</div>' +
        _tbl(df, 'tbl_stock', sid='srch_stock',
             fmt={
                 '最新Slope分數': lambda v: _n(v, 6) if pd.notna(v) else '─',
                 '平均持有天數': lambda v: _n(v, 1) if pd.notna(v) else '─',
             },
             badge=badge_map) +
        '</div>\n'
    )


def _settings_html(meta):
    """回測設定資訊表。"""
    rows = [
        ('標的指數',    meta.get('index', '─')),
        ('持股數',      str(meta.get('stk_num', '─'))),
        ('初始資金',    _a(meta.get('ini_amt', np.nan))),
        ('停損設定',    _p(meta.get('stop_loss', np.nan))),
        ('回測期間',    f"{meta.get('start_date','─')} ～ {meta.get('end_date','─')}"),
        ('Slope 期間', str(meta.get('period', meta.get('best_period', '─'))) + ' 天'),
        ('換股門檻',    _n(meta.get('crt_chg', meta.get('best_crt_chg', np.nan)), 4)),
    ]
    rows_html = ''.join(f'<tr class="srow"><td>{k}</td><td>{v}</td></tr>' for k, v in rows)
    return (
        '<div class="sec-card">'
        '<div class="sec-title">回測參數設定</div>'
        f'<table class="stbl"><tbody>{rows_html}</tbody></table>'
        '</div>\n'
    )


# ═══════════════════════════════════════════════════════════════════════════════
# §6  公開介面：單次回測報表
# ═══════════════════════════════════════════════════════════════════════════════

def build_backtest_report(performance, performance_year, performance_tlt,
                          hold_portfolio, trade, holdings,
                          meta, output_path='slope_backtest_report.html',
                          auto_open=True):
    """
    產生單次回測互動式 HTML 報表。

    Parameters
    ----------
    performance      : 每日績效 DataFrame (index=date)
    performance_year : 逐年績效 DataFrame
    performance_tlt  : 總體績效 DataFrame (index=['p','b'])
    hold_portfolio   : 每日持倉 DataFrame
    trade            : 交易紀錄 DataFrame (index=date)
    holdings         : 最終持倉狀態 DataFrame (index=stk_bbg)
    meta             : dict 含 index, stk_num, ini_amt, stop_loss,
                            period, crt_chg, start_date, end_date
    output_path      : 輸出 HTML 路徑
    auto_open        : 是否自動以瀏覽器開啟
    """
    # ── 衍生資料 ──────────────────────────────────────────────────────────────
    trade_log  = _compute_trade_log(hold_portfolio, trade)
    stock_prof = _compute_stock_profile(trade_log, hold_portfolio, trade)

    pp = performance_tlt.loc['p']
    pb = performance_tlt.loc['b']
    avg_alpha = performance_year['alpha'].mean()
    total_p   = _sg(performance['p_ret_cul'].iloc[-1]) - 1
    total_b   = _sg(performance['b_ret_cul'].iloc[-1]) - 1

    # ── 圖表 ──────────────────────────────────────────────────────────────────
    c_cum = _chart_cum_ret(performance)
    c_ann = _chart_annual(performance_year)

    # ── Tab 內容 ──────────────────────────────────────────────────────────────

    # Tab 1: 績效總覽
    t1 = (
        _kpi_html(pp, pb, avg_alpha, total_p, total_b) +
        _metrics_tbl(pp, pb, avg_alpha, total_p, total_b)
    )

    # Tab 2: 圖表分析
    t2 = (
        '<div class="sec-card"><div class="sec-title">策略 vs 大盤：累積報酬率 &amp; 回撤</div>'
        + c_cum + '</div>\n'
        '<div class="sec-card"><div class="sec-title">逐年報酬率比較</div>'
        + c_ann + '</div>\n'
    )

    # Tab 3: 逐年績效
    t3 = _annual_tbl(performance_year)

    # Tab 4: 每日績效
    t4 = _daily_perf_tbl(performance)

    # Tab 5: 持倉明細
    t5 = _holdings_tbl(trade_log)

    # Tab 6: 換股紀錄
    t6 = _trade_tbl(trade_log, trade)

    # Tab 7: 個股分析
    t7 = _stock_prof_tbl(stock_prof)

    # Tab 8: 回測設定
    t8 = _settings_html(meta)

    # ── 組合頁面 ──────────────────────────────────────────────────────────────
    tab_list = [
        ('t1', '績效總覽',   t1),
        ('t2', '圖表分析',   t2),
        ('t3', '逐年績效',   t3),
        ('t4', '每日績效',   t4),
        ('t5', '持倉明細',   t5),
        ('t6', '換股紀錄',   t6),
        ('t7', '個股分析',   t7),
        ('t8', '回測設定',   t8),
    ]

    start = meta.get('start_date', '─')
    end   = meta.get('end_date',   '─')
    idx   = meta.get('index',      '─')
    header = (
        f'<div class="mb-3">'
        f'<div class="rpt-title">Slope 策略回測報表</div>'
        f'<div class="rpt-sub">'
        f'回測區間：{start} ～ {end}　｜　'
        f'標的指數：{idx}　｜　'
        f'持股數：{meta.get("stk_num","─")}　｜　'
        f'Slope 期間：{meta.get("period","─")} 天　｜　'
        f'換股門檻：{_n(meta.get("crt_chg", np.nan), 4)}'
        f'</div></div>\n'
    )

    html = (
        _html_head('Slope 策略回測報表') +
        header +
        _tabs_html(tab_list) +
        _html_tail()
    )

    with open(output_path, 'w', encoding='utf-8') as f:
        f.write(html)

    if auto_open:
        webbrowser.open('file:///' + os.path.abspath(output_path).replace('\\', '/'))

    return output_path


# ═══════════════════════════════════════════════════════════════════════════════
# §7  公開介面：最佳化回測報表
# ═══════════════════════════════════════════════════════════════════════════════

def _opt_overview_tab(df_opt, meta):
    """最佳化總覽：最佳參數 Banner + 熱圖 + 散點圖。"""
    best_period  = meta.get('best_period',  '─')
    best_crt_chg = meta.get('best_crt_chg', np.nan)
    # best row stats
    mask = (
        (df_opt['para_period'] == best_period) &
        (np.abs(df_opt['para_crt_chg'] - best_crt_chg) < 1e-9)
    )
    best = df_opt[mask].iloc[0] if mask.any() else df_opt.iloc[0]
    best_ret   = float(best['ret'])
    best_alpha = int(best['alpha_year'])

    banner = (
        '<div class="best-card">'
        '<div style="font-size:.95rem;font-weight:700;margin-bottom:14px;opacity:.92;">最佳參數組合</div>'
        '<div class="best-row">'
        f'<div class="best-item"><div class="bc-val">{int(best_period)}</div><div class="bc-lbl">Slope 期間 (天)</div></div>'
        f'<div class="best-item"><div class="bc-val">{_n(best_crt_chg,4)}</div><div class="bc-lbl">換股門檻</div></div>'
        f'<div class="best-item"><div class="bc-val">{_p(best_ret - 1)}</div><div class="bc-lbl">累積報酬率</div></div>'
        f'<div class="best-item"><div class="bc-val">{best_alpha}</div><div class="bc-lbl">Alpha 勝出年數</div></div>'
        f'<div class="best-item"><div class="bc-val">{df_opt.shape[0]}</div><div class="bc-lbl">總組合數</div></div>'
        '</div></div>\n'
    )

    heatmap_div = _chart_opt_heatmap(df_opt)
    scatter_div = _chart_opt_scatter(df_opt)

    return (
        banner +
        '<div class="sec-card"><div class="sec-title">參數熱圖</div>' + heatmap_div + '</div>\n' +
        '<div class="sec-card"><div class="sec-title">散點分布圖（各組合累積報酬率 vs Alpha年數）</div>' + scatter_div + '</div>\n'
    )


def _opt_detail_tab(df_opt):
    """最佳化詳細結果表格。"""
    df = df_opt.copy().sort_values(['alpha_year', 'ret'], ascending=[False, False])
    df = df.reset_index(drop=True)
    df.columns = ['Slope期間', '換股門檻', '累積報酬率', 'Alpha勝出年數']
    return (
        '<div class="sec-card">'
        '<div class="sec-title">所有參數組合結果</div>' +
        _tbl(df, 'tbl_opt', sid='srch_opt',
             fmt={
                 '換股門檻':  lambda v: _n(v, 4),
                 '累積報酬率': lambda v: _p(v - 1),
                 'Alpha勝出年數': lambda v: str(int(v)),
             },
             cls_fn={
                 '累積報酬率': lambda v: _cls(v - 1),
             }) +
        '</div>\n'
    )


def build_report(df_opt,
                 performance, performance_year, performance_tlt,
                 hold_portfolio, trade,
                 meta, output_path='slope_demo_report.html',
                 auto_open=True):
    """
    產生最佳化回測互動式 HTML 報表。

    Parameters
    ----------
    df_opt           : 最佳化結果 DataFrame (para_period, para_crt_chg, ret, alpha_year)
    performance      : 最佳參數每日績效 DataFrame
    performance_year : 最佳參數逐年績效 DataFrame
    performance_tlt  : 最佳參數總體績效 DataFrame
    hold_portfolio   : 最佳參數每日持倉 DataFrame
    trade            : 最佳參數交易紀錄 DataFrame
    meta             : dict 含 index, stk_num, ini_amt, stop_loss,
                            best_period, best_crt_chg, start_date, end_date
    output_path      : 輸出 HTML 路徑
    auto_open        : 是否自動以瀏覽器開啟
    """
    # ── 衍生資料 ──────────────────────────────────────────────────────────────
    trade_log  = _compute_trade_log(hold_portfolio, trade)
    stock_prof = _compute_stock_profile(trade_log, hold_portfolio, trade)

    pp = performance_tlt.loc['p']
    pb = performance_tlt.loc['b']
    avg_alpha = performance_year['alpha'].mean()
    total_p   = _sg(performance['p_ret_cul'].iloc[-1]) - 1
    total_b   = _sg(performance['b_ret_cul'].iloc[-1]) - 1

    # ── 圖表 ──────────────────────────────────────────────────────────────────
    c_cum = _chart_cum_ret(performance)
    c_ann = _chart_annual(performance_year)

    # ── Tab 內容 ──────────────────────────────────────────────────────────────

    # Tab 1: 最佳化總覽
    t_opt = _opt_overview_tab(df_opt, meta)

    # Tab 2: 參數明細
    t_detail = _opt_detail_tab(df_opt)

    # Tab 3: 最佳參數績效總覽
    t_perf = (
        _kpi_html(pp, pb, avg_alpha, total_p, total_b) +
        _metrics_tbl(pp, pb, avg_alpha, total_p, total_b)
    )

    # Tab 4: 圖表分析
    t_chart = (
        '<div class="sec-card"><div class="sec-title">策略 vs 大盤：累積報酬率 &amp; 回撤</div>'
        + c_cum + '</div>\n'
        '<div class="sec-card"><div class="sec-title">逐年報酬率比較</div>'
        + c_ann + '</div>\n'
    )

    # Tab 5: 逐年績效
    t_annual = _annual_tbl(performance_year)

    # Tab 6: 換股紀錄
    t_trade = _trade_tbl(trade_log, trade)

    # Tab 7: 個股分析
    t_stock = _stock_prof_tbl(stock_prof)

    # Tab 8: 回測設定
    # 組合 meta 加入 best 參數欄位（供 settings 顯示）
    smeta = dict(meta)
    smeta.setdefault('period',  meta.get('best_period',  '─'))
    smeta.setdefault('crt_chg', meta.get('best_crt_chg', np.nan))
    t_settings = _settings_html(smeta)

    # ── 組合頁面 ──────────────────────────────────────────────────────────────
    tab_list = [
        ('to1', '最佳化總覽',      t_opt),
        ('to2', '參數比較',        t_detail),
        ('to3', '最佳參數績效',    t_perf),
        ('to4', '圖表分析',        t_chart),
        ('to5', '逐年績效',        t_annual),
        ('to6', '換股紀錄',        t_trade),
        ('to7', '個股分析',        t_stock),
        ('to8', '回測設定',        t_settings),
    ]

    start = meta.get('start_date', '─')
    end   = meta.get('end_date',   '─')
    idx   = meta.get('index',      '─')
    bp    = meta.get('best_period',  '─')
    bc    = meta.get('best_crt_chg', np.nan)
    header = (
        f'<div class="mb-3">'
        f'<div class="rpt-title">Slope 策略最佳化報表</div>'
        f'<div class="rpt-sub">'
        f'回測區間：{start} ～ {end}　｜　'
        f'標的指數：{idx}　｜　'
        f'持股數：{meta.get("stk_num","─")}　｜　'
        f'最佳 Slope 期間：{bp} 天　｜　'
        f'最佳換股門檻：{_n(bc,4)}'
        f'</div></div>\n'
    )

    html = (
        _html_head('Slope 策略最佳化報表') +
        header +
        _tabs_html(tab_list) +
        _html_tail()
    )

    with open(output_path, 'w', encoding='utf-8') as f:
        f.write(html)

    if auto_open:
        webbrowser.open('file:///' + os.path.abspath(output_path).replace('\\', '/'))

    return output_path
